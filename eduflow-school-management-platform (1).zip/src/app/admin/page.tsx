import { AdminDashboard } from "@/components/portal/admin-dashboard";
import { PortalFrame } from "@/components/portal/portal-frame";
import { getAdminData, getTenantSlug } from "@/lib/eduflow-data";

interface AdminPageProps {
  searchParams?: Promise<{ tenant?: string }>;
}

export default async function AdminPage({ searchParams }: AdminPageProps) {
  const params = (await searchParams) ?? {};
  const tenant = getTenantSlug(params.tenant);
  const data = getAdminData(tenant);

  return (
    <PortalFrame
      role="admin"
      title={`Admin Portal — ${data.tenant.name}`}
      subtitle="Track school-wide metrics, manage users, and configure core operations."
    >
      <AdminDashboard data={data} />
    </PortalFrame>
  );
}
