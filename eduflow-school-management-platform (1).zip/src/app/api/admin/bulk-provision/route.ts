import { db } from "@/db";
import { tenants, users } from "@/db/schema";
import { eq } from "drizzle-orm";

interface ProvisionUserPayload {
  name: string;
  role: "teacher" | "parent";
  phone?: string;
  email?: string;
}

interface BulkProvisionPayload {
  tenantSlug?: string;
  tenantName?: string;
  tenantCity?: string;
  users?: ProvisionUserPayload[];
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as BulkProvisionPayload;

    const tenantSlug = body.tenantSlug?.trim();
    const tenantName = body.tenantName?.trim();
    const tenantCity = body.tenantCity?.trim();
    const incomingUsers = body.users ?? [];

    if (!tenantSlug || !tenantName || !tenantCity || incomingUsers.length === 0) {
      return Response.json({ ok: false, message: "Invalid payload" }, { status: 400 });
    }

    const sanitizedUsers = incomingUsers
      .map((item) => ({
        name: item.name.trim(),
        role: item.role,
        phone: item.phone?.trim(),
        email: item.email?.trim(),
      }))
      .filter((item) => item.name.length >= 2);

    if (sanitizedUsers.length === 0) {
      return Response.json({ ok: false, message: "No valid users found" }, { status: 400 });
    }

    let tenantRecord = (await db.select().from(tenants).where(eq(tenants.slug, tenantSlug)).limit(1))[0];

    if (!tenantRecord) {
      const [created] = await db
        .insert(tenants)
        .values({ slug: tenantSlug, name: tenantName, city: tenantCity })
        .returning();
      tenantRecord = created;
    }

    await db.insert(users).values(
      sanitizedUsers.map((item) => ({
        tenantId: tenantRecord.id,
        fullName: item.name,
        role: item.role,
        phone: item.phone,
        email: item.email,
        status: "invited",
      })),
    );

    return Response.json({ ok: true, inserted: sanitizedUsers.length });
  } catch {
    return Response.json({ ok: false, message: "Bulk provisioning failed" }, { status: 500 });
  }
}
