import { db } from "@/db";
import { feeChallans, students, tenants, users } from "@/db/schema";
import { and, eq, sql } from "drizzle-orm";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const tenantSlug = url.searchParams.get("tenant")?.trim();

    if (!tenantSlug) {
      return Response.json({ ok: false, message: "tenant is required" }, { status: 400 });
    }

    const [tenantRecord] = await db.select().from(tenants).where(eq(tenants.slug, tenantSlug)).limit(1);

    if (!tenantRecord) {
      return Response.json({
        ok: true,
        sync: {
          syncedAtIso: new Date().toISOString(),
          dbUsers: 0,
          dbStudents: 0,
          dbChallans: 0,
          dbPendingPkr: 0,
          dbPaidPkr: 0,
        },
      });
    }

    const [userCountRow] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(users)
      .where(eq(users.tenantId, tenantRecord.id));

    const [studentCountRow] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(students)
      .where(eq(students.tenantId, tenantRecord.id));

    const [challanCountRow] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(feeChallans)
      .where(eq(feeChallans.tenantId, tenantRecord.id));

    const [pendingRow] = await db
      .select({ amount: sql<number>`coalesce(sum(${feeChallans.amountPkr}), 0)::int` })
      .from(feeChallans)
      .where(and(eq(feeChallans.tenantId, tenantRecord.id), eq(feeChallans.paid, false)));

    const [paidRow] = await db
      .select({ amount: sql<number>`coalesce(sum(${feeChallans.amountPkr}), 0)::int` })
      .from(feeChallans)
      .where(and(eq(feeChallans.tenantId, tenantRecord.id), eq(feeChallans.paid, true)));

    return Response.json({
      ok: true,
      sync: {
        syncedAtIso: new Date().toISOString(),
        dbUsers: userCountRow?.count ?? 0,
        dbStudents: studentCountRow?.count ?? 0,
        dbChallans: challanCountRow?.count ?? 0,
        dbPendingPkr: pendingRow?.amount ?? 0,
        dbPaidPkr: paidRow?.amount ?? 0,
      },
    });
  } catch {
    return Response.json({ ok: false, message: "Unable to sync admin state" }, { status: 500 });
  }
}
