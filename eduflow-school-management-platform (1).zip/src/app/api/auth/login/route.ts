import { eq } from "drizzle-orm";
import { db } from "@/db";
import { authUsers } from "@/db/schema";
import { verifyPassword } from "@/lib/auth-crypto";
import { createSession, ensureAuthSeedData, setSessionCookie } from "@/lib/auth-session";

interface LoginPayload {
  email?: string;
  password?: string;
}

function getRoleRedirect(role: string) {
  if (role === "super_admin") return "/super-admin";
  if (role === "school_admin") return "/school-admin";
  if (role === "teacher") return "/teacher-app";
  return "/parent-app";
}

export async function POST(request: Request) {
  try {
    await ensureAuthSeedData();

    const body = (await request.json()) as LoginPayload;
    const email = body.email?.trim().toLowerCase() ?? "";
    const password = body.password?.trim() ?? "";

    if (!email || !password) {
      return Response.json({ ok: false, message: "Email and password are required." }, { status: 400 });
    }

    const [user] = await db.select().from(authUsers).where(eq(authUsers.email, email)).limit(1);

    if (!user || !user.isActive) {
      return Response.json({ ok: false, message: "Invalid credentials." }, { status: 401 });
    }

    const validPassword = await verifyPassword(password, user.passwordHash);
    if (!validPassword) {
      return Response.json({ ok: false, message: "Invalid credentials." }, { status: 401 });
    }

    const token = await createSession(user.id);
    await setSessionCookie(token);

    return Response.json({
      ok: true,
      role: user.role,
      redirectTo: getRoleRedirect(user.role),
    });
  } catch {
    return Response.json({ ok: false, message: "Unable to login right now." }, { status: 500 });
  }
}
