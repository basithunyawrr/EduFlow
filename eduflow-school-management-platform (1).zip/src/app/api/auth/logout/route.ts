import { and, eq } from "drizzle-orm";
import { cookies } from "next/headers";
import { db } from "@/db";
import { authSessions } from "@/db/schema";
import { clearSessionCookie, SESSION_COOKIE_NAME } from "@/lib/auth-session";
import { createHash } from "crypto";

function hashSessionToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export async function POST() {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get(SESSION_COOKIE_NAME)?.value;

    if (token) {
      await db.delete(authSessions).where(and(eq(authSessions.tokenHash, hashSessionToken(token))));
    }

    await clearSessionCookie();
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false, message: "Failed to logout" }, { status: 500 });
  }
}
