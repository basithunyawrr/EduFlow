import { getSessionUser } from "@/lib/auth-session";

export async function GET() {
  try {
    const user = await getSessionUser();
    if (!user) {
      return Response.json({ ok: false, user: null }, { status: 401 });
    }

    return Response.json({ ok: true, user });
  } catch {
    return Response.json({ ok: false, user: null }, { status: 500 });
  }
}
