import { db } from "@/db";
import { demoRequests } from "@/db/schema";

interface DemoPayload {
  name?: string;
  schoolName?: string;
  city?: string;
  phone?: string;
}

function isValidPhone(phone: string) {
  return /^\+?\d[\d\s-]{8,15}$/.test(phone.trim());
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as DemoPayload;

    const name = body.name?.trim() ?? "";
    const schoolName = body.schoolName?.trim() ?? "";
    const city = body.city?.trim() ?? "";
    const phone = body.phone?.trim() ?? "";

    if (!name || !schoolName || !city || !isValidPhone(phone)) {
      return Response.json({ ok: false, message: "Invalid payload" }, { status: 400 });
    }

    await db.insert(demoRequests).values({
      name,
      schoolName,
      city,
      phone,
      source: "landing-page",
    });

    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false, message: "Unable to save request" }, { status: 500 });
  }
}
