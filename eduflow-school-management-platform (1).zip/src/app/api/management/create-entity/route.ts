import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { authUsers, feeChallans, students, tenants, users } from "@/db/schema";
import { hashPassword } from "@/lib/auth-crypto";
import { getSessionUser, logRoleAction } from "@/lib/auth-session";
import { hasPermission } from "@/lib/authz";

type EntityType = "school" | "school_admin" | "teacher" | "parent" | "student" | "fee_challan";

interface CreateEntityPayload {
  entityType?: EntityType;
  tenantSlug?: string;
  fullName?: string;
  email?: string;
  password?: string;
  phone?: string;
  role?: "school_admin" | "teacher" | "parent";
  grade?: string;
  section?: string;
  rollNo?: string;
  studentId?: string;
  schoolName?: string;
  city?: string;
  monthLabel?: string;
  amountPkr?: number;
  dueDate?: string;
}

function normalizeEmail(email?: string) {
  return email?.trim().toLowerCase() ?? "";
}

export async function POST(request: Request) {
  try {
    const actor = await getSessionUser();
    if (!actor) {
      return Response.json({ ok: false, message: "Unauthorized" }, { status: 401 });
    }

    const body = (await request.json()) as CreateEntityPayload;
    if (!body.entityType) {
      return Response.json({ ok: false, message: "entityType is required" }, { status: 400 });
    }

    const entityType = body.entityType;

    const requiredPermissionByEntity: Record<EntityType, Parameters<typeof hasPermission>[1]> = {
      school: "create_school",
      school_admin: "create_school_admin",
      teacher: "create_teacher",
      parent: "create_parent",
      student: "create_student",
      fee_challan: "generate_fee_challan",
    };

    const requiredPermission = requiredPermissionByEntity[entityType];
    if (!hasPermission(actor.role, requiredPermission)) {
      return Response.json({ ok: false, message: "Forbidden: insufficient permissions" }, { status: 403 });
    }

    let tenantRecord = actor.tenantId
      ? (await db.select().from(tenants).where(eq(tenants.id, actor.tenantId)).limit(1))[0]
      : undefined;

    if (actor.role === "super_admin" && body.tenantSlug) {
      tenantRecord = (await db.select().from(tenants).where(eq(tenants.slug, body.tenantSlug)).limit(1))[0];
    }

    if (entityType === "school") {
      const schoolName = body.schoolName?.trim();
      const city = body.city?.trim();
      const slug = body.tenantSlug?.trim();
      if (!schoolName || !city || !slug) {
        return Response.json({ ok: false, message: "schoolName, city, tenantSlug are required" }, { status: 400 });
      }

      await db.insert(tenants).values({
        name: schoolName,
        city,
        slug,
        subscriptionPlan: "starter",
      });

      await logRoleAction({
        actorUserId: actor.id,
        action: "create_school",
        details: `${schoolName} (${slug})`,
      });

      return Response.json({ ok: true, message: "School created" });
    }

    if (!tenantRecord) {
      return Response.json({ ok: false, message: "Tenant context missing" }, { status: 400 });
    }

    if (entityType === "student") {
      const fullName = body.fullName?.trim();
      const grade = body.grade?.trim();
      const section = body.section?.trim();
      const rollNo = body.rollNo?.trim();

      if (!fullName || !grade || !section || !rollNo) {
        return Response.json({ ok: false, message: "fullName, grade, section, rollNo are required" }, { status: 400 });
      }

      await db.insert(students).values({
        tenantId: tenantRecord.id,
        fullName,
        grade,
        section,
        rollNo,
      });

      await logRoleAction({
        actorUserId: actor.id,
        tenantId: tenantRecord.id,
        action: "create_student",
        details: `${fullName} (${grade}-${section})`,
      });

      return Response.json({ ok: true, message: "Student created" });
    }

    if (entityType === "fee_challan") {
      const studentId = body.studentId?.trim();
      const monthLabel = body.monthLabel?.trim();
      const amountPkr = Number(body.amountPkr);
      const dueDate = body.dueDate ? new Date(body.dueDate) : null;

      if (!studentId || !monthLabel || !Number.isFinite(amountPkr) || !dueDate) {
        return Response.json(
          { ok: false, message: "studentId, monthLabel, amountPkr, dueDate are required" },
          { status: 400 },
        );
      }

      const studentRecord = await db
        .select()
        .from(students)
        .where(and(eq(students.id, studentId), eq(students.tenantId, tenantRecord.id)))
        .limit(1);

      if (studentRecord.length === 0) {
        return Response.json({ ok: false, message: "Student not found in your tenant" }, { status: 404 });
      }

      await db.insert(feeChallans).values({
        tenantId: tenantRecord.id,
        studentId,
        monthLabel,
        amountPkr,
        dueDate,
        paid: false,
      });

      await logRoleAction({
        actorUserId: actor.id,
        tenantId: tenantRecord.id,
        action: "generate_fee_challan",
        details: `${monthLabel} ${amountPkr}`,
      });

      return Response.json({ ok: true, message: "Fee challan generated" });
    }

    const fullName = body.fullName?.trim();
    const email = normalizeEmail(body.email);
    const password = body.password?.trim() ?? "";

    if (!fullName || !email || password.length < 8) {
      return Response.json({ ok: false, message: "fullName, valid email and password (8+) required" }, { status: 400 });
    }

    const role = entityType === "school_admin" ? "school_admin" : entityType;

    const existing = await db.select().from(authUsers).where(eq(authUsers.email, email)).limit(1);
    if (existing.length > 0) {
      return Response.json({ ok: false, message: "User already exists" }, { status: 409 });
    }

    const passwordHash = await hashPassword(password);

    await db.insert(authUsers).values({
      tenantId: tenantRecord.id,
      fullName,
      email,
      role,
      passwordHash,
      isActive: true,
    });

    await db.insert(users).values({
      tenantId: tenantRecord.id,
      fullName,
      role,
      email,
      phone: body.phone?.trim() || null,
      status: "active",
    });

    await logRoleAction({
      actorUserId: actor.id,
      tenantId: tenantRecord.id,
      action: `create_${entityType}`,
      details: `${fullName} (${email})`,
    });

    return Response.json({ ok: true, message: `${entityType} account created` });
  } catch {
    return Response.json({ ok: false, message: "Failed to process request" }, { status: 500 });
  }
}
