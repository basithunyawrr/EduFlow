import { eq } from "drizzle-orm";
import { db } from "@/db";
import { students, tenants } from "@/db/schema";
import { getSessionUser } from "@/lib/auth-session";

export async function GET(request: Request) {
  try {
    const actor = await getSessionUser();
    if (!actor) {
      return Response.json({ ok: false, message: "Unauthorized" }, { status: 401 });
    }

    const url = new URL(request.url);
    const tenantSlug = url.searchParams.get("tenant")?.trim();

    const tenantRecord = actor.role === "super_admin" && tenantSlug
      ? (await db.select().from(tenants).where(eq(tenants.slug, tenantSlug)).limit(1))[0]
      : actor.tenantId
        ? (await db.select().from(tenants).where(eq(tenants.id, actor.tenantId)).limit(1))[0]
        : undefined;

    if (!tenantRecord) {
      return Response.json({ ok: false, message: "Tenant not found" }, { status: 404 });
    }

    const tenantStudents = await db
      .select({ id: students.id, fullName: students.fullName, grade: students.grade, section: students.section, rollNo: students.rollNo })
      .from(students)
      .where(eq(students.tenantId, tenantRecord.id));

    return Response.json({
      ok: true,
      tenant: {
        id: tenantRecord.id,
        slug: tenantRecord.slug,
        name: tenantRecord.name,
        city: tenantRecord.city,
        subscriptionPlan: tenantRecord.subscriptionPlan,
      },
      students: tenantStudents,
    });
  } catch {
    return Response.json({ ok: false, message: "Unable to load tenant state" }, { status: 500 });
  }
}
