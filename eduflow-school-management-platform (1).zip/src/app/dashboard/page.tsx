import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth-session";

export default async function DashboardRouterPage() {
  const user = await getSessionUser();
  if (!user) {
    redirect("/login");
  }

  if (user.role === "super_admin") redirect("/super-admin");
  if (user.role === "school_admin") redirect("/school-admin");
  if (user.role === "teacher") redirect("/teacher-app");
  redirect("/parent-app");
}
