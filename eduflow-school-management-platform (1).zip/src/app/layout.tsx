import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "EduFlow — School Management System for Pakistan",
  description:
    "EduFlow is a multi-tenant school management SaaS that digitizes attendance, fee challans, homework, grading, and parent communication.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-100 text-slate-900 antialiased">{children}</body>
    </html>
  );
}
