"use client";

import { useState } from "react";

interface LoginResult {
  ok: boolean;
  message?: string;
  redirectTo?: string;
}

export default function LoginPage() {
  const [email, setEmail] = useState("superadmin@eduflow.pk");
  const [password, setPassword] = useState("SuperAdmin@123");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  async function handleLogin(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const payload = (await response.json()) as LoginResult;
      if (!response.ok || !payload.ok) {
        setMessage(payload.message ?? "Login failed.");
        return;
      }

      window.location.href = payload.redirectTo ?? "/dashboard";
    } catch {
      setMessage("Unable to login right now.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-sky-50 px-4 py-10">
      <div className="mx-auto w-full max-w-2xl rounded-3xl border border-slate-200 bg-white p-6 shadow-sm md:p-8">
        <h1 className="text-3xl font-bold text-slate-900">EduFlow Secure Login</h1>
        <p className="mt-2 text-sm text-slate-600">
          Login with your role credentials. Super Admin access is protected and only available via direct Super Admin credentials.
        </p>

        <form onSubmit={handleLogin} className="mt-6 space-y-4">
          <label className="block text-sm font-medium text-slate-700">
            Email
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2"
              required
            />
          </label>
          <label className="block text-sm font-medium text-slate-700">
            Password
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2"
              required
            />
          </label>

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-50"
          >
            {loading ? "Signing in..." : "Login"}
          </button>
        </form>

        {message ? <p className="mt-3 text-sm text-amber-700">{message}</p> : null}

        <div className="mt-6 rounded-2xl border border-slate-200 bg-slate-50 p-4 text-xs text-slate-600">
          <p className="font-semibold text-slate-700">Demo Credentials</p>
          <ul className="mt-2 space-y-1">
            <li>Super Admin: superadmin@eduflow.pk / SuperAdmin@123</li>
            <li>School Admin: admin.alnoor@eduflow.pk / SchoolAdmin@123</li>
            <li>Teacher: teacher.alnoor@eduflow.pk / Teacher@123</li>
            <li>Parent: parent.alnoor@eduflow.pk / Parent@123</li>
          </ul>
          <p className="mt-2">Public demo portals remain available at /portal for visitor testing.</p>
        </div>
      </div>
    </main>
  );
}
