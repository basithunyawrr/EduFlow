import { ParentDashboard } from "@/components/portal/parent-dashboard";
import { SecureFrame } from "@/components/secure/secure-frame";
import { requireSessionUser } from "@/lib/auth-session";
import { getParentData, getTenantSlug } from "@/lib/eduflow-data";

interface ParentAppPageProps {
  searchParams?: Promise<{ tenant?: string }>;
}

export default async function ParentAppPage({ searchParams }: ParentAppPageProps) {
  const user = await requireSessionUser(["parent", "teacher", "school_admin", "super_admin"]);
  const params = (await searchParams) ?? {};
  const tenantSlug = user.role === "super_admin" ? getTenantSlug(params.tenant) : getTenantSlug(user.tenantSlug);
  const data = getParentData(tenantSlug);

  return (
    <SecureFrame
      user={user}
      title={`Parent / Student Workspace — ${data.studentName}`}
      subtitle="Access attendance, report cards, challans, and receipt verification under active subscription rules."
    >
      <ParentDashboard data={data} />
    </SecureFrame>
  );
}
