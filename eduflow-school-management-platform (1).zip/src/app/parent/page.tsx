import { ParentDashboard } from "@/components/portal/parent-dashboard";
import { PortalFrame } from "@/components/portal/portal-frame";
import { getParentData, getTenantSlug } from "@/lib/eduflow-data";

interface ParentPageProps {
  searchParams?: Promise<{ tenant?: string }>;
}

export default async function ParentPage({ searchParams }: ParentPageProps) {
  const params = (await searchParams) ?? {};
  const tenant = getTenantSlug(params.tenant);
  const data = getParentData(tenant);

  return (
    <PortalFrame
      role="parent"
      title={`Student/Parent Portal — ${data.studentName}`}
      subtitle="Stay connected with timetable, attendance, fee challans, and academic progress."
    >
      <ParentDashboard data={data} />
    </PortalFrame>
  );
}
