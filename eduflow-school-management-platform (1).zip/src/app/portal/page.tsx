import Link from "next/link";
import { ArrowRight, Building2, GraduationCap, ShieldUser, Users } from "lucide-react";
import { tenants } from "@/lib/eduflow-data";

export default function PortalPage() {
  const defaultTenant = tenants[0].slug;

  const cards = [
    {
      title: "Admin Portal",
      description: "For school owners, principals, and administrators.",
      href: `/admin?tenant=${defaultTenant}`,
      icon: ShieldUser,
    },
    {
      title: "Teacher Portal",
      description: "Manage attendance, homework, and grading workflows.",
      href: `/teacher?tenant=${defaultTenant}`,
      icon: GraduationCap,
    },
    {
      title: "Student/Parent Portal",
      description: "View timetable, attendance, report cards, and challans.",
      href: `/parent?tenant=${defaultTenant}`,
      icon: Users,
    },
  ];

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-sky-50 px-4 py-10 md:px-8">
      <div className="mx-auto w-full max-w-5xl">
        <Link href="/" className="text-sm font-semibold text-slate-700 hover:text-slate-900">
          ← Back to Home
        </Link>

        <div className="mt-5 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm md:p-8">
          <h1 className="text-3xl font-bold text-slate-900">EduFlow Portal Login</h1>
          <p className="mt-2 text-sm text-slate-600">Choose your role to continue into your school workspace.</p>

          <div className="mt-5 inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-4 py-2 text-sm text-slate-700">
            <Building2 className="h-4 w-4" />
            Multi-tenant mode active across {tenants.length} demo schools
          </div>

          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {cards.map((card) => (
              <Link
                key={card.title}
                href={card.href}
                className="group rounded-2xl border border-slate-200 bg-slate-50 p-5 transition hover:-translate-y-1 hover:border-slate-300 hover:bg-white hover:shadow-lg"
              >
                <card.icon className="h-6 w-6 text-slate-900" />
                <h2 className="mt-3 text-lg font-semibold text-slate-900">{card.title}</h2>
                <p className="mt-1 text-sm text-slate-600">{card.description}</p>
                <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-slate-800 group-hover:text-slate-900">
                  Open Portal <ArrowRight className="h-4 w-4" />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}
