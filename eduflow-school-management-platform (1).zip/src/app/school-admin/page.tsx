import { AdminDashboard } from "@/components/portal/admin-dashboard";
import { EntityManager } from "@/components/secure/entity-manager";
import { SecureFrame } from "@/components/secure/secure-frame";
import { requireSessionUser } from "@/lib/auth-session";
import { getAdminData, getTenantSlug } from "@/lib/eduflow-data";

interface SchoolAdminPageProps {
  searchParams?: Promise<{ tenant?: string }>;
}

export default async function SchoolAdminPage({ searchParams }: SchoolAdminPageProps) {
  const user = await requireSessionUser(["school_admin", "super_admin"]);
  const params = (await searchParams) ?? {};
  const tenantSlug = user.role === "super_admin" ? getTenantSlug(params.tenant) : getTenantSlug(user.tenantSlug);
  const data = getAdminData(tenantSlug);

  return (
    <SecureFrame
      user={user}
      title={`School Admin Dashboard — ${data.tenant.name}`}
      subtitle="Manage campus operations, users, fee workflows, and subscription-bound features."
    >
      <div className="grid gap-5">
        <EntityManager actorRole={user.role === "super_admin" ? "super_admin" : "school_admin"} defaultTenantSlug={tenantSlug} />
        <AdminDashboard data={data} />
      </div>
    </SecureFrame>
  );
}
