import { EntityManager } from "@/components/secure/entity-manager";
import { SecureFrame } from "@/components/secure/secure-frame";
import { requireSessionUser } from "@/lib/auth-session";
import { getRolePermissions } from "@/lib/authz";

export default async function SuperAdminPage() {
  const user = await requireSessionUser(["super_admin"]);
  const permissions = getRolePermissions(user.role);

  return (
    <SecureFrame
      user={user}
      title="Super Admin — God Mode"
      subtitle="Full platform control across all tenants, roles, and subscription governance."
    >
      <div className="grid gap-5 lg:grid-cols-2">
        <EntityManager actorRole="super_admin" defaultTenantSlug={user.tenantSlug ?? "al-noor"} />

        <article className="rounded-2xl border border-slate-200 bg-white p-5">
          <h2 className="text-lg font-semibold text-slate-900">Hierarchical Permissions Matrix</h2>
          <ul className="mt-3 space-y-1 text-sm text-slate-700">
            {permissions.map((permission) => (
              <li key={permission}>• {permission.replaceAll("_", " ")}</li>
            ))}
          </ul>
          <p className="mt-4 rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs text-emerald-700">
            Super Admin access is strictly protected via authenticated session and direct credentials.
          </p>
        </article>
      </div>
    </SecureFrame>
  );
}
