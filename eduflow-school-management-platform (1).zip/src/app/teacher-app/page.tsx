import { TeacherDashboard } from "@/components/portal/teacher-dashboard";
import { EntityManager } from "@/components/secure/entity-manager";
import { SecureFrame } from "@/components/secure/secure-frame";
import { requireSessionUser } from "@/lib/auth-session";
import { getTeacherData, getTenantSlug } from "@/lib/eduflow-data";

interface TeacherAppPageProps {
  searchParams?: Promise<{ tenant?: string }>;
}

export default async function TeacherAppPage({ searchParams }: TeacherAppPageProps) {
  const user = await requireSessionUser(["teacher", "super_admin", "school_admin"]);
  const params = (await searchParams) ?? {};
  const tenantSlug = user.role === "super_admin" ? getTenantSlug(params.tenant) : getTenantSlug(user.tenantSlug);
  const data = getTeacherData(tenantSlug);

  return (
    <SecureFrame
      user={user}
      title={`Teacher Workspace — ${data.teacherName}`}
      subtitle="Class-focused attendance, homework, and marks workflows under role and plan constraints."
    >
      <div className="grid gap-5">
        <EntityManager actorRole={user.role === "super_admin" ? "super_admin" : user.role === "school_admin" ? "school_admin" : "teacher"} defaultTenantSlug={tenantSlug} />
        <TeacherDashboard data={data} />
      </div>
    </SecureFrame>
  );
}
