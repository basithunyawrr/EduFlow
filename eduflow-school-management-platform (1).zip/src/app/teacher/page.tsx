import { PortalFrame } from "@/components/portal/portal-frame";
import { TeacherDashboard } from "@/components/portal/teacher-dashboard";
import { getTeacherData, getTenantSlug } from "@/lib/eduflow-data";

interface TeacherPageProps {
  searchParams?: Promise<{ tenant?: string }>;
}

export default async function TeacherPage({ searchParams }: TeacherPageProps) {
  const params = (await searchParams) ?? {};
  const tenant = getTenantSlug(params.tenant);
  const data = getTeacherData(tenant);

  return (
    <PortalFrame
      role="teacher"
      title={`Teacher Portal — ${data.teacherName}`}
      subtitle="Mark attendance, post homework, and update student grades with ease."
    >
      <TeacherDashboard data={data} />
    </PortalFrame>
  );
}
