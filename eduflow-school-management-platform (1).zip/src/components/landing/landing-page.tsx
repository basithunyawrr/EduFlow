"use client";

import { useMemo, useState } from "react";
import {
  ArrowRight,
  BadgeCheck,
  BookOpenCheck,
  CalendarClock,
  CheckCircle2,
  ChevronDown,
  MessageCircle,
  Phone,
  ShieldCheck,
  WalletCards,
  XCircle,
} from "lucide-react";
import { formatPkr } from "@/lib/format";

const whatsappLink = "https://wa.me/923127803616";

const oldWay = [
  "Paper attendance registers are delayed or misplaced",
  "Fee follow-ups consume admin hours every month",
  "Parents miss timely updates about homework and progress",
  "Manual report prep creates inconsistencies and stress",
];

const eduFlowWay = [
  "Daily attendance with instant parent visibility",
  "Digital challans and transparent payment tracking",
  "One dashboard for homework, diary, grading, and communication",
  "Leadership analytics for confident school growth decisions",
];

const features = [
  {
    title: "Real-Time Attendance",
    text: "Track Present, Absent, and Late status class-wise in seconds.",
    icon: CalendarClock,
  },
  {
    title: "Digital Fee Challans",
    text: "Generate and verify challans with complete month-by-month visibility.",
    icon: WalletCards,
  },
  {
    title: "Homework & Digital Diary",
    text: "Teachers post daily work while parents stay informed automatically.",
    icon: BookOpenCheck,
  },
  {
    title: "Transparent Grading",
    text: "Assessments, marks, and remarks are organized and parent-ready.",
    icon: ShieldCheck,
  },
];

const pricingPlans = [
  {
    name: "Starter Plan",
    target: "Basic operations for small schools",
    pricePkr: 2500,
    billing: "per month",
    points: [
      "Basic student directory",
      "Simple attendance tracking",
      "Advanced fee challans locked",
      "Advanced analytics locked",
    ],
  },
  {
    name: "Professional Campus Plan",
    target: "Growing schools requiring core automation",
    pricePkr: 5000,
    billing: "per month",
    points: [
      "Digital fee challans",
      "Homework and diary modules",
      "Standard report cards",
      "Role-based operational workflows",
    ],
  },
  {
    name: "Enterprise Network Plan",
    target: "Multi-campus and network-level institutions",
    pricePkr: 10000,
    billing: "per month",
    points: [
      "Multi-campus tracking",
      "Automated SMS/challan reminders",
      "Advanced analytics and oversight",
      "Full platform suite with expansion controls",
    ],
  },
];

const faqItems = [
  {
    q: "How secure is EduFlow for school and student data?",
    a: "EduFlow follows role-based access controls, tenant-isolated data architecture, and server-side validation. Each school’s records stay logically separated to protect privacy and trust.",
  },
  {
    q: "Can we migrate from manual registers and paper challans?",
    a: "Yes. EduFlow is built for offline-to-online migration. Our onboarding process helps import student records, classes, and fee structures in a phased and staff-friendly manner.",
  },
  {
    q: "Will our non-technical staff be able to use this?",
    a: "Absolutely. The interface is intentionally simple with guided workflows for admins, teachers, and parents. We also provide role-specific orientation support during implementation.",
  },
  {
    q: "Do parents need technical setup for the portal?",
    a: "No complicated setup is required. Parents access a clean, mobile-friendly portal to view attendance, grades, timetable, and fee status quickly.",
  },
];

const testimonials = [
  {
    quote:
      "EduFlow gave us operational clarity. Fee follow-up became measurable and attendance discipline improved immediately.",
    name: "Principal Uzma Rahman",
    role: "Lahore",
  },
  {
    quote:
      "Our parent communication transformed. Families trust us more because updates are now transparent and timely.",
    name: "School Owner Farhan Qureshi",
    role: "Karachi",
  },
  {
    quote:
      "Teachers adapted quickly, and our admin workload reduced within weeks.",
    name: "Operations Lead Hira Malik",
    role: "Islamabad",
  },
];

interface LeadFormState {
  name: string;
  schoolName: string;
  city: string;
  phone: string;
}

interface LeadFormErrors {
  name?: string;
  schoolName?: string;
  city?: string;
  phone?: string;
}

const initialLeadForm: LeadFormState = {
  name: "",
  schoolName: "",
  city: "",
  phone: "",
};

function validateLeadForm(form: LeadFormState): LeadFormErrors {
  const errors: LeadFormErrors = {};
  if (form.name.trim().length < 2) errors.name = "Please enter a valid name.";
  if (form.schoolName.trim().length < 2) errors.schoolName = "Please enter your school name.";
  if (form.city.trim().length < 2) errors.city = "Please enter your city.";
  if (!/^\+?\d[\d\s-]{8,15}$/.test(form.phone.trim())) {
    errors.phone = "Please enter a valid phone number.";
  }
  return errors;
}

export function LandingPage() {
  const [leadForm, setLeadForm] = useState<LeadFormState>(initialLeadForm);
  const [isSubmitting, setSubmitting] = useState(false);
  const [resultMessage, setResultMessage] = useState<string>("");
  const [openFaqIndex, setOpenFaqIndex] = useState<number>(0);
  const [touched, setTouched] = useState<Record<keyof LeadFormState, boolean>>({
    name: false,
    schoolName: false,
    city: false,
    phone: false,
  });

  const errors = useMemo(() => validateLeadForm(leadForm), [leadForm]);
  const isFormValid = useMemo(() => Object.keys(errors).length === 0, [errors]);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    setTouched({ name: true, schoolName: true, city: true, phone: true });

    if (!isFormValid) {
      setResultMessage("Please correct the highlighted fields to continue.");
      return;
    }

    setSubmitting(true);
    setResultMessage("");

    try {
      const res = await fetch("/api/demo-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(leadForm),
      });

      if (!res.ok) {
        throw new Error("Unable to submit right now.");
      }

      setLeadForm(initialLeadForm);
      setTouched({ name: false, schoolName: false, city: false, phone: false });
      setResultMessage("Thank you! Your demo request has been submitted.");
    } catch {
      setResultMessage("Could not submit now. Please use WhatsApp for instant support.");
    } finally {
      setSubmitting(false);
    }
  }

  function getInputClass(field: keyof LeadFormErrors) {
    const hasError = touched[field] && errors[field];
    return `mt-1 w-full rounded-xl border bg-white px-3 py-2 text-sm outline-none focus:ring-2 ${
      hasError
        ? "border-amber-400 focus:ring-amber-200"
        : "border-slate-300 focus:ring-slate-200"
    }`;
  }

  return (
    <main className="relative overflow-x-hidden bg-gradient-to-b from-slate-50 via-white to-sky-50 text-slate-800">
      <a
        href={whatsappLink}
        target="_blank"
        rel="noreferrer"
        className="fixed bottom-5 right-5 z-50 inline-flex items-center gap-2 rounded-full bg-emerald-600 px-5 py-3 text-sm font-semibold text-white shadow-lg transition hover:scale-[1.03] hover:bg-emerald-700"
      >
        <MessageCircle className="h-4 w-4" />
        WhatsApp Chat
      </a>

      <header className="sticky top-0 z-40 border-b border-slate-200/80 bg-white/90 backdrop-blur">
        <nav className="mx-auto flex w-full max-w-7xl items-center justify-between px-4 py-4 md:px-8">
          <div className="text-xl font-bold tracking-tight text-slate-900">
            Edu<span className="text-amber-600">Flow</span>
          </div>
          <ul className="hidden items-center gap-6 text-sm font-medium md:flex">
            <li><a href="#home" className="hover:text-slate-900">Home</a></li>
            <li><a href="#goal" className="hover:text-slate-900">Our Goal</a></li>
            <li><a href="#know-about-us" className="hover:text-slate-900">Know About Us</a></li>
            <li><a href="#demo" className="hover:text-slate-900">Book a Demo</a></li>
            <li><a href="#contact" className="hover:text-slate-900">Contact Us</a></li>
          </ul>
          <div className="flex items-center gap-2">
            <a
              href="/login"
              className="hidden rounded-full border border-slate-300 px-4 py-2 text-xs font-semibold text-slate-700 transition hover:border-slate-500 hover:text-slate-900 sm:inline-flex"
            >
              Secure Login
            </a>
            <a
              href="/portal"
              className="hidden rounded-full border border-slate-300 px-4 py-2 text-xs font-semibold text-slate-700 transition hover:border-slate-500 hover:text-slate-900 lg:inline-flex"
            >
              Demo Portals
            </a>
            <a
              href={whatsappLink}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-slate-900 px-4 py-2 text-xs font-semibold text-white transition hover:bg-slate-800"
            >
              <Phone className="h-3.5 w-3.5" />
              WhatsApp
            </a>
          </div>
        </nav>
      </header>

      <section id="home" className="mx-auto grid w-full max-w-7xl gap-10 px-4 pb-16 pt-14 md:grid-cols-2 md:px-8 md:pt-20">
        <div>
          <p className="inline-flex items-center gap-2 rounded-full bg-slate-900 px-4 py-1 text-xs font-semibold uppercase tracking-wide text-white">
            Pakistan’s School Operations Platform
          </p>
          <h1 className="mt-5 text-4xl font-bold leading-tight text-slate-900 sm:text-5xl">
            The Complete Operating System for Modern Schools
          </h1>
          <p className="mt-5 max-w-xl text-base leading-relaxed text-slate-600">
            Streamline attendance, fee collections, and parent communication in one practical platform designed for principals, owners, and administrators.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href="#demo"
              className="inline-flex items-center gap-2 rounded-full bg-slate-900 px-6 py-3 text-sm font-semibold text-white transition hover:bg-slate-800"
            >
              Book a Live Demo
              <ArrowRight className="h-4 w-4" />
            </a>
            <a
              href="/portal"
              className="inline-flex items-center gap-2 rounded-full border border-slate-300 bg-white px-6 py-3 text-sm font-semibold text-slate-700 transition hover:border-slate-500 hover:text-slate-900"
            >
              Explore Role Portals
            </a>
          </div>
        </div>

        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-[0_25px_80px_rgba(15,23,42,0.08)]">
          <h3 className="text-sm font-semibold uppercase tracking-wide text-slate-500">Why schools trust EduFlow</h3>
          <div className="mt-4 space-y-4">
            {[
              "No more scattered registers and manual reconciliation",
              "Faster fee collection follow-up with clean records",
              "Clear parent communication in one place",
              "Simple onboarding for non-technical teams",
            ].map((item) => (
              <div key={item} className="flex items-start gap-3">
                <CheckCircle2 className="mt-0.5 h-5 w-5 text-emerald-600" />
                <p className="text-sm text-slate-700">{item}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="goal" className="mx-auto w-full max-w-7xl px-4 py-14 md:px-8">
        <div className="grid gap-6 rounded-3xl border border-slate-200 bg-white p-6 md:grid-cols-2 md:p-8">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">The Old Way vs. The EduFlow Way</h2>
            <p className="mt-3 text-sm text-slate-600">
              Replace fragmented, paper-heavy operations with a connected digital workflow your staff can adopt quickly.
            </p>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
              <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                <XCircle className="h-4 w-4" /> Old Way
              </h3>
              <ul className="mt-3 space-y-2 text-sm text-slate-700/90">
                {oldWay.map((item) => (
                  <li key={item}>• {item}</li>
                ))}
              </ul>
            </div>
            <div className="rounded-2xl border border-emerald-100 bg-emerald-50 p-4">
              <h3 className="flex items-center gap-2 text-sm font-semibold text-emerald-700">
                <BadgeCheck className="h-4 w-4" /> EduFlow Way
              </h3>
              <ul className="mt-3 space-y-2 text-sm text-emerald-700/90">
                {eduFlowWay.map((item) => (
                  <li key={item}>• {item}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section id="know-about-us" className="mx-auto w-full max-w-7xl px-4 py-2 md:px-8 md:py-10">
        <div className="rounded-3xl border border-slate-200 bg-white p-6 md:p-8">
          <h2 className="text-2xl font-bold text-slate-900">Know About Us</h2>
          <p className="mt-3 max-w-4xl text-sm leading-relaxed text-slate-600">
            EduFlow exists to empower schools across Pakistan with practical automation. Our mission is to help school owners and administrators replace manual paperwork with clear, connected systems that improve trust, efficiency, and student outcomes. We focus on simplicity first, so every staff member—from front-desk operators to senior principals—can confidently manage day-to-day operations without technical complexity.
          </p>
          <div className="mt-5 grid gap-3 sm:grid-cols-3">
            {[
              "Paperless operations with audit-ready records",
              "Parent confidence through transparent communication",
              "Scalable design for single and multi-campus institutions",
            ].map((point) => (
              <div key={point} className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700">
                {point}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="about" className="mx-auto w-full max-w-7xl px-4 py-6 md:px-8 md:py-12">
        <h2 className="text-center text-2xl font-bold text-slate-900">Core Features Built for Pakistani Schools</h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature) => (
            <article
              key={feature.title}
              className="group rounded-2xl border border-slate-200 bg-white p-5 transition hover:-translate-y-1 hover:border-slate-300 hover:shadow-lg"
            >
              <feature.icon className="h-7 w-7 text-slate-900 transition group-hover:scale-110" />
              <h3 className="mt-4 text-lg font-semibold text-slate-900">{feature.title}</h3>
              <p className="mt-2 text-sm text-slate-600">{feature.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="mx-auto w-full max-w-7xl px-4 py-8 md:px-8 md:py-12">
        <h2 className="text-center text-2xl font-bold text-slate-900">Pricing Plans for Schools</h2>
        <p className="mx-auto mt-2 max-w-2xl text-center text-sm text-slate-600">
          Choose a plan that aligns with your institution size. All plans include onboarding and continuous product support.
        </p>
        <div className="mt-7 grid gap-4 md:grid-cols-3">
          {pricingPlans.map((plan) => (
            <article key={plan.name} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <h3 className="text-lg font-semibold text-slate-900">{plan.name}</h3>
              <p className="mt-1 text-xs font-medium uppercase tracking-wide text-slate-500">{plan.target}</p>
              <p className="mt-3 text-2xl font-bold text-slate-900">{formatPkr(plan.pricePkr)}</p>
              <p className="text-xs text-slate-500">{plan.billing}</p>
              <ul className="mt-4 space-y-2 text-sm text-slate-700">
                {plan.points.map((point) => (
                  <li key={point} className="flex items-start gap-2">
                    <CheckCircle2 className="mt-0.5 h-4 w-4 text-emerald-600" />
                    {point}
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      <section className="mx-auto w-full max-w-7xl px-4 py-8 md:px-8 md:py-12">
        <h2 className="text-center text-2xl font-bold text-slate-900">Trusted by School Leaders & Families</h2>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {testimonials.map((testimonial) => (
            <figure key={testimonial.name} className="rounded-2xl border border-slate-200 bg-white p-5">
              <blockquote className="text-sm leading-relaxed text-slate-700">“{testimonial.quote}”</blockquote>
              <figcaption className="mt-4 text-sm font-semibold text-slate-900">{testimonial.name}</figcaption>
              <p className="text-xs text-slate-500">{testimonial.role}</p>
            </figure>
          ))}
        </div>
      </section>

      <section className="mx-auto w-full max-w-5xl px-4 py-8 md:px-8 md:py-12">
        <h2 className="text-center text-2xl font-bold text-slate-900">Frequently Asked Questions</h2>
        <div className="mt-6 space-y-3">
          {faqItems.map((faq, idx) => {
            const open = openFaqIndex === idx;
            return (
              <article key={faq.q} className="rounded-2xl border border-slate-200 bg-white">
                <button
                  onClick={() => setOpenFaqIndex(open ? -1 : idx)}
                  className="flex w-full items-center justify-between gap-3 px-4 py-3 text-left"
                >
                  <span className="text-sm font-semibold text-slate-800">{faq.q}</span>
                  <ChevronDown className={`h-4 w-4 text-slate-500 transition ${open ? "rotate-180" : ""}`} />
                </button>
                {open ? <p className="border-t border-slate-200 px-4 py-3 text-sm text-slate-600">{faq.a}</p> : null}
              </article>
            );
          })}
        </div>
      </section>

      <footer id="contact" className="border-t border-slate-200 bg-white">
        <div id="demo" className="mx-auto grid w-full max-w-7xl gap-8 px-4 py-14 md:grid-cols-2 md:px-8">
          <div>
            <h2 className="text-2xl font-bold text-slate-900">Book a Personalized Demo</h2>
            <p className="mt-3 text-sm text-slate-600">
              Share your campus details and we will schedule a practical walkthrough aligned to your operations.
            </p>
            <a
              href={whatsappLink}
              target="_blank"
              rel="noreferrer"
              className="mt-5 inline-flex items-center gap-2 rounded-full bg-emerald-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-emerald-700"
            >
              <MessageCircle className="h-4 w-4" />
              Direct WhatsApp: +92 312 7803616
            </a>
          </div>

          <form onSubmit={handleSubmit} className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="text-sm font-medium text-slate-700">
                Name
                <input
                  className={getInputClass("name")}
                  value={leadForm.name}
                  onBlur={() => setTouched((prev) => ({ ...prev, name: true }))}
                  onChange={(e) => setLeadForm((prev) => ({ ...prev, name: e.target.value }))}
                  required
                />
                {touched.name && errors.name ? <span className="mt-1 block text-xs text-amber-700">{errors.name}</span> : null}
              </label>
              <label className="text-sm font-medium text-slate-700">
                School Name
                <input
                  className={getInputClass("schoolName")}
                  value={leadForm.schoolName}
                  onBlur={() => setTouched((prev) => ({ ...prev, schoolName: true }))}
                  onChange={(e) => setLeadForm((prev) => ({ ...prev, schoolName: e.target.value }))}
                  required
                />
                {touched.schoolName && errors.schoolName ? <span className="mt-1 block text-xs text-amber-700">{errors.schoolName}</span> : null}
              </label>
              <label className="text-sm font-medium text-slate-700">
                City
                <input
                  className={getInputClass("city")}
                  value={leadForm.city}
                  onBlur={() => setTouched((prev) => ({ ...prev, city: true }))}
                  onChange={(e) => setLeadForm((prev) => ({ ...prev, city: e.target.value }))}
                  required
                />
                {touched.city && errors.city ? <span className="mt-1 block text-xs text-amber-700">{errors.city}</span> : null}
              </label>
              <label className="text-sm font-medium text-slate-700">
                Phone Number
                <input
                  className={getInputClass("phone")}
                  placeholder="03xx xxxxxxx"
                  value={leadForm.phone}
                  onBlur={() => setTouched((prev) => ({ ...prev, phone: true }))}
                  onChange={(e) => setLeadForm((prev) => ({ ...prev, phone: e.target.value }))}
                  required
                />
                {touched.phone && errors.phone ? <span className="mt-1 block text-xs text-amber-700">{errors.phone}</span> : null}
              </label>
            </div>
            <button
              type="submit"
              disabled={isSubmitting}
              className="mt-4 inline-flex w-full items-center justify-center rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {isSubmitting ? "Submitting..." : "Book Demo"}
            </button>
            {resultMessage ? <p className="mt-3 text-sm text-slate-700">{resultMessage}</p> : null}
          </form>
        </div>

        <div className="border-t border-slate-200 py-5 text-center text-xs text-slate-500">
          © {new Date().getFullYear()} EduFlow — Multi-tenant school management SaaS for Pakistan.
        </div>
      </footer>
    </main>
  );
}
