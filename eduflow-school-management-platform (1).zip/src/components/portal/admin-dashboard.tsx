"use client";

import { useEffect, useMemo, useState } from "react";
import { BellRing, RefreshCw, Settings2, UserPlus, Users } from "lucide-react";
import type { AdminDashboardData, AdminRealtimeSync, FeeCollectionRow } from "@/lib/eduflow-types";
import { formatDate, formatPkr } from "@/lib/format";
import { getPlanLabel, planHasFeature } from "@/lib/authz";

interface AdminDashboardProps {
  data: AdminDashboardData;
}

type FeeStatusFilter = "all" | "healthy" | "at-risk";

interface ProvisionDraftRow {
  name: string;
  role: "teacher" | "parent";
  phone: string;
  email: string;
}

const initialSyncState: AdminRealtimeSync = {
  syncedAtIso: new Date().toISOString(),
  dbUsers: 0,
  dbStudents: 0,
  dbChallans: 0,
  dbPendingPkr: 0,
  dbPaidPkr: 0,
};

export function AdminDashboard({ data }: AdminDashboardProps) {
  const [users, setUsers] = useState(data.users);
  const [newUserName, setNewUserName] = useState("");
  const [newUserRole, setNewUserRole] = useState<"teacher" | "parent">("teacher");
  const [autoSms, setAutoSms] = useState(true);
  const [feeReminder, setFeeReminder] = useState(true);

  const plan = data.tenant.subscriptionPlan;
  const canUseFeeChallans = planHasFeature(plan, "fee_challans_digital");
  const canUseAdvancedAnalytics = planHasFeature(plan, "analytics_advanced");
  const canUseAutomatedReminders = planHasFeature(plan, "automated_sms_reminders");

  const [monthFilter, setMonthFilter] = useState<string>("all");
  const [classFilter, setClassFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<FeeStatusFilter>("all");

  const [provisionInput, setProvisionInput] = useState(
    "Sadia Malik,teacher,03001234567,sadia@example.com\nHamza Imran,parent,03007654321,hamza@example.com",
  );
  const [provisionRows, setProvisionRows] = useState<ProvisionDraftRow[]>([]);
  const [provisionMessage, setProvisionMessage] = useState("");
  const [isProvisioning, setProvisioning] = useState(false);

  const [syncState, setSyncState] = useState<AdminRealtimeSync>(initialSyncState);
  const [isSyncLoading, setSyncLoading] = useState(false);

  const monthOptions = useMemo(
    () => Array.from(new Set(data.feeCollections.map((item) => item.month))),
    [data.feeCollections],
  );

  const classOptions = useMemo(
    () => Array.from(new Set(data.feeCollections.map((item) => item.classLabel))),
    [data.feeCollections],
  );

  const totalInvites = useMemo(() => users.filter((u) => u.status === "invited").length, [users]);

  const filteredFeeRows = useMemo(() => {
    if (!canUseFeeChallans) return [];
    return data.feeCollections.filter((row) => {
      if (monthFilter !== "all" && row.month !== monthFilter) return false;
      if (classFilter !== "all" && row.classLabel !== classFilter) return false;
      if (statusFilter !== "all" && row.status !== statusFilter) return false;
      return true;
    });
  }, [canUseFeeChallans, data.feeCollections, monthFilter, classFilter, statusFilter]);

  const filteredFeeTotals = useMemo(() => {
    return filteredFeeRows.reduce(
      (acc, row) => {
        acc.amount += row.amountPkr;
        acc.paid += row.paidPkr;
        acc.pending += row.pendingPkr;
        return acc;
      },
      { amount: 0, paid: 0, pending: 0 },
    );
  }, [filteredFeeRows]);

  function inviteSingleUser() {
    if (!newUserName.trim()) return;
    setUsers((prev) => [...prev, { name: newUserName.trim(), role: newUserRole, status: "invited" }]);
    setNewUserName("");
  }

  function parseProvisionInput() {
    const rows = provisionInput
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean)
      .map((line) => {
        const [name = "", role = "teacher", phone = "", email = ""] = line.split(",").map((part) => part.trim());
        return {
          name,
          role: role === "parent" ? "parent" : "teacher",
          phone,
          email,
        } satisfies ProvisionDraftRow;
      })
      .filter((row) => row.name.length >= 2);

    setProvisionRows(rows);
    setProvisionMessage(rows.length > 0 ? `${rows.length} user rows ready for bulk provisioning.` : "No valid rows found.");
  }

  async function runBulkProvision() {
    if (provisionRows.length === 0) {
      setProvisionMessage("Please parse valid rows before provisioning.");
      return;
    }

    setProvisioning(true);
    setProvisionMessage("");

    try {
      const res = await fetch("/api/admin/bulk-provision", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tenantSlug: data.tenant.slug,
          tenantName: data.tenant.name,
          tenantCity: data.tenant.city,
          users: provisionRows,
        }),
      });

      const payload = (await res.json()) as { ok: boolean; inserted?: number; message?: string };

      if (!res.ok || !payload.ok) {
        setProvisionMessage(payload.message ?? "Bulk provisioning failed.");
        return;
      }

      setProvisionMessage(`Bulk provisioning complete: ${payload.inserted ?? 0} users invited.`);
      setUsers((prev) => [
        ...prev,
        ...provisionRows.map((row) => ({ name: row.name, role: row.role, status: "invited" as const })),
      ]);
    } catch {
      setProvisionMessage("Bulk provisioning failed due to a network error.");
    } finally {
      setProvisioning(false);
      await fetchSyncState();
    }
  }

  async function fetchSyncState() {
    if (!canUseAdvancedAnalytics) return;

    setSyncLoading(true);
    try {
      const res = await fetch(`/api/admin/sync?tenant=${data.tenant.slug}`);
      const payload = (await res.json()) as { ok: boolean; sync?: AdminRealtimeSync };
      if (res.ok && payload.ok && payload.sync) {
        setSyncState(payload.sync);
      }
    } catch {
      // ignore transient sync errors
    } finally {
      setSyncLoading(false);
    }
  }

  useEffect(() => {
    if (!canUseAdvancedAnalytics) return;
    void fetchSyncState();
    const interval = setInterval(() => {
      void fetchSyncState();
    }, 12000);
    return () => clearInterval(interval);
  }, [data.tenant.slug, canUseAdvancedAnalytics]);

  return (
    <div className="grid gap-6">
      <div className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-xs text-slate-700">
        Active Subscription: <span className="font-semibold">{getPlanLabel(plan)}</span>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        {[
          { label: "Active Students", value: data.activeStudents.toLocaleString() },
          { label: "Active Teachers", value: data.activeTeachers.toLocaleString() },
          { label: "Monthly Revenue", value: formatPkr(data.monthlyCollectionPkr) },
          { label: "Attendance Today", value: `${data.attendanceTodayPercent}%` },
          { label: "Pending Fees", value: formatPkr(data.pendingFeesPkr) },
        ].map((metric) => (
          <article key={metric.label} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <p className="text-xs uppercase tracking-wide text-slate-500">{metric.label}</p>
            <p className="mt-2 text-2xl font-semibold text-slate-900">{metric.value}</p>
          </article>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <article className="rounded-2xl border border-slate-200 bg-white p-5 lg:col-span-2">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-lg font-semibold text-slate-900">User Management</h2>
            <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-700">
              {totalInvites} pending invites
            </span>
          </div>

          <div className="mt-4 grid gap-3 sm:grid-cols-[1fr_140px_110px]">
            <input
              value={newUserName}
              onChange={(e) => setNewUserName(e.target.value)}
              placeholder="Enter staff or parent name"
              className="rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-200"
            />
            <select
              value={newUserRole}
              onChange={(e) => setNewUserRole(e.target.value as "teacher" | "parent")}
              className="rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-sm outline-none"
            >
              <option value="teacher">Teacher</option>
              <option value="parent">Parent</option>
            </select>
            <button
              onClick={inviteSingleUser}
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white transition hover:bg-slate-800"
            >
              <UserPlus className="h-4 w-4" /> Invite
            </button>
          </div>

          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-[560px] text-left text-sm">
              <thead className="text-slate-500">
                <tr>
                  <th className="py-2">Name</th>
                  <th className="py-2">Role</th>
                  <th className="py-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user, idx) => (
                  <tr key={`${user.name}-${idx}`} className="border-t border-slate-100">
                    <td className="py-2 font-medium text-slate-800">{user.name}</td>
                    <td className="py-2 capitalize text-slate-600">{user.role}</td>
                    <td className="py-2">
                      <span
                        className={`rounded-full px-2.5 py-1 text-xs font-semibold ${
                          user.status === "active" ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"
                        }`}
                      >
                        {user.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </article>

        <article className="rounded-2xl border border-slate-200 bg-white p-5">
          <h2 className="inline-flex items-center gap-2 text-lg font-semibold text-slate-900">
            <Settings2 className="h-5 w-5 text-slate-900" />
            System Settings
          </h2>
          <div className="mt-4 space-y-3">
            <label className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
              <span className="text-sm text-slate-700">Auto SMS Alerts</span>
              <input type="checkbox" checked={autoSms} onChange={() => setAutoSms((v) => !v)} />
            </label>
            <label className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
              <span className="text-sm text-slate-700">Fee Reminders</span>
              <input type="checkbox" checked={feeReminder} onChange={() => setFeeReminder((v) => !v)} />
            </label>
            {!canUseAutomatedReminders ? (
              <div className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-700">
                Automated reminders are available on Enterprise Network.
              </div>
            ) : null}
            <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-700">
              <BellRing className="mr-1 inline h-3.5 w-3.5" />
              Configuration updates are saved for this session demo.
            </div>
          </div>
        </article>
      </div>

      <article className="rounded-2xl border border-slate-200 bg-white p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-lg font-semibold text-slate-900">Fee Collection Tracking</h2>
          {!canUseFeeChallans ? (
            <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-700">
              Locked on Starter Plan
            </span>
          ) : null}
          <div className="flex flex-wrap gap-2">
            <select
              value={monthFilter}
              onChange={(e) => setMonthFilter(e.target.value)}
              className="rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs"
            >
              <option value="all">All months</option>
              {monthOptions.map((month) => (
                <option key={month} value={month}>
                  {month}
                </option>
              ))}
            </select>
            <select
              value={classFilter}
              onChange={(e) => setClassFilter(e.target.value)}
              className="rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs"
            >
              <option value="all">All classes</option>
              {classOptions.map((cls) => (
                <option key={cls} value={cls}>
                  {cls}
                </option>
              ))}
            </select>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as FeeStatusFilter)}
              className="rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-xs"
            >
              <option value="all">All status</option>
              <option value="healthy">Healthy</option>
              <option value="at-risk">At Risk</option>
            </select>
          </div>
        </div>

        {!canUseFeeChallans ? (
          <p className="mt-3 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-700">
            Digital fee challans and fee analytics require Professional Campus or Enterprise Network plan.
          </p>
        ) : null}

        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
            <p className="text-xs text-slate-500">Expected</p>
            <p className="text-sm font-semibold text-slate-900">{formatPkr(filteredFeeTotals.amount)}</p>
          </div>
          <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2">
            <p className="text-xs text-emerald-700">Collected</p>
            <p className="text-sm font-semibold text-emerald-800">{formatPkr(filteredFeeTotals.paid)}</p>
          </div>
          <div className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2">
            <p className="text-xs text-amber-700">Pending</p>
            <p className="text-sm font-semibold text-amber-800">{formatPkr(filteredFeeTotals.pending)}</p>
          </div>
        </div>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[680px] text-left text-sm">
            <thead className="text-slate-500">
              <tr>
                <th className="py-2">Month</th>
                <th className="py-2">Class</th>
                <th className="py-2">Expected</th>
                <th className="py-2">Collected</th>
                <th className="py-2">Pending</th>
                <th className="py-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredFeeRows.map((row: FeeCollectionRow) => (
                <tr key={row.id} className="border-t border-slate-100">
                  <td className="py-2">{row.month}</td>
                  <td className="py-2">{row.classLabel}</td>
                  <td className="py-2">{formatPkr(row.amountPkr)}</td>
                  <td className="py-2">{formatPkr(row.paidPkr)}</td>
                  <td className="py-2">{formatPkr(row.pendingPkr)}</td>
                  <td className="py-2">
                    <span
                      className={`rounded-full px-2 py-1 text-xs font-semibold ${
                        row.status === "healthy" ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"
                      }`}
                    >
                      {row.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </article>

      <article className="rounded-2xl border border-slate-200 bg-white p-5">
        <h2 className="inline-flex items-center gap-2 text-lg font-semibold text-slate-900">
          <Users className="h-5 w-5" /> Bulk User Provisioning
        </h2>
        <p className="mt-1 text-xs text-slate-500">Use CSV-like lines: Name,role,phone,email</p>

        <textarea
          rows={5}
          value={provisionInput}
          onChange={(e) => setProvisionInput(e.target.value)}
          className="mt-3 w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-200"
        />

        <div className="mt-3 flex flex-wrap gap-2">
          <button
            onClick={parseProvisionInput}
            className="rounded-xl border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
          >
            Parse Users
          </button>
          <button
            disabled={isProvisioning}
            onClick={runBulkProvision}
            className="rounded-xl bg-slate-900 px-4 py-2 text-xs font-semibold text-white hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {isProvisioning ? "Provisioning..." : "Run Bulk Provision"}
          </button>
        </div>

        {provisionRows.length > 0 ? (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-[600px] text-left text-sm">
              <thead className="text-slate-500">
                <tr>
                  <th className="py-2">Name</th>
                  <th className="py-2">Role</th>
                  <th className="py-2">Phone</th>
                  <th className="py-2">Email</th>
                </tr>
              </thead>
              <tbody>
                {provisionRows.map((row, idx) => (
                  <tr key={`${row.name}-${idx}`} className="border-t border-slate-100">
                    <td className="py-2">{row.name}</td>
                    <td className="py-2 capitalize">{row.role}</td>
                    <td className="py-2">{row.phone || "-"}</td>
                    <td className="py-2">{row.email || "-"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}

        {provisionMessage ? <p className="mt-3 text-xs text-slate-700">{provisionMessage}</p> : null}
      </article>

      <article className="rounded-2xl border border-slate-200 bg-white p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-lg font-semibold text-slate-900">Real-Time Database Sync</h2>
          {!canUseAdvancedAnalytics ? (
            <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-700">
              Advanced analytics locked
            </span>
          ) : null}
          <button
            onClick={fetchSyncState}
            disabled={!canUseAdvancedAnalytics}
            className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-slate-50 px-3 py-1.5 text-xs font-semibold text-slate-700 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${isSyncLoading ? "animate-spin" : ""}`} /> Refresh
          </button>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-5">
          <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-700">DB Users: {canUseAdvancedAnalytics ? syncState.dbUsers : "Locked"}</div>
          <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-700">DB Students: {canUseAdvancedAnalytics ? syncState.dbStudents : "Locked"}</div>
          <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-700">DB Challans: {canUseAdvancedAnalytics ? syncState.dbChallans : "Locked"}</div>
          <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs text-emerald-700">Paid: {canUseAdvancedAnalytics ? formatPkr(syncState.dbPaidPkr) : "Locked"}</div>
          <div className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-700">Pending: {canUseAdvancedAnalytics ? formatPkr(syncState.dbPendingPkr) : "Locked"}</div>
        </div>
        <p className="mt-3 text-xs text-slate-500">
          Last synced: {canUseAdvancedAnalytics ? formatDate(syncState.syncedAtIso) : "Upgrade to Enterprise"}
        </p>
      </article>
    </div>
  );
}
