"use client";

import { useMemo, useState } from "react";
import {
  BadgeCheck,
  CalendarDays,
  CircleCheck,
  Download,
  ReceiptText,
  SearchCheck,
  ShieldCheck,
} from "lucide-react";
import type { ParentDashboardData } from "@/lib/eduflow-types";
import { formatDate, formatPkr } from "@/lib/format";
import { getPlanLabel, planHasFeature } from "@/lib/authz";

interface ParentDashboardProps {
  data: ParentDashboardData;
}

type VerificationState = "idle" | "verified" | "not-found";

export function ParentDashboard({ data }: ParentDashboardProps) {
  const [receiptQuery, setReceiptQuery] = useState("");
  const [verificationState, setVerificationState] = useState<VerificationState>("idle");

  const plan = data.subscriptionPlan;
  const canUseDigitalChallans = planHasFeature(plan, "fee_challans_digital");
  const canUseReportCards = planHasFeature(plan, "report_cards_standard");

  const attendanceRate = useMemo(() => {
    if (data.attendanceHistory.length === 0) return 0;
    return Math.round((data.attendanceHistory.filter((a) => a.present).length / data.attendanceHistory.length) * 100);
  }, [data.attendanceHistory]);

  const matchingChallan = useMemo(() => {
    const normalized = receiptQuery.trim().toUpperCase();
    if (!normalized) return undefined;
    return data.challans.find((challan) => challan.receiptId?.toUpperCase() === normalized);
  }, [data.challans, receiptQuery]);

  const verificationMessage = useMemo(() => {
    if (!canUseDigitalChallans) {
      return "Receipt verification is available from the Professional Campus plan.";
    }

    if (!receiptQuery.trim()) return "Enter receipt ID to verify challan payment.";
    if (matchingChallan) return `Verified: ${matchingChallan.month} challan was paid successfully.`;
    return "No record found. Please contact school admin if payment was recently made.";
  }, [canUseDigitalChallans, matchingChallan, receiptQuery]);

  function verifyReceipt() {
    if (!canUseDigitalChallans) {
      setVerificationState("not-found");
      return;
    }

    const normalized = receiptQuery.trim();
    if (!normalized) {
      setVerificationState("idle");
      return;
    }
    setVerificationState(matchingChallan ? "verified" : "not-found");
  }

  function downloadChallan(month: string) {
    if (!canUseDigitalChallans) return;

    const challan = data.challans.find((item) => item.month === month);
    if (!challan) return;

    const content = [
      "EduFlow Digital Fee Challan",
      "-------------------------",
      `Student: ${data.studentName}`,
      `Class: ${data.grade} ${data.section}`,
      `Roll No: ${data.rollNo}`,
      `Month: ${challan.month}`,
      `Challan No: ${challan.challanNo ?? "N/A"}`,
      `Branch: ${challan.branchName ?? "N/A"}`,
      `Amount: ${formatPkr(challan.amountPkr)}`,
      `Due Date: ${formatDate(challan.dueDate)}`,
      `Status: ${challan.paid ? "Paid" : "Unpaid"}`,
      `Receipt ID: ${challan.receiptId ?? "Pending"}`,
    ].join("\n");

    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${data.studentName.replace(/\s+/g, "-")}-${challan.month.replace(/\s+/g, "-")}-challan.txt`;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="grid gap-6">
      <div className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-xs text-slate-700">
        Active Subscription: <span className="font-semibold">{getPlanLabel(plan)}</span>
      </div>

      <article className="rounded-2xl border border-slate-200 bg-white p-5">
        <h2 className="text-lg font-semibold text-slate-900">Student Snapshot</h2>
        <div className="mt-3 grid gap-3 sm:grid-cols-4">
          {[
            { label: "Student", value: data.studentName },
            { label: "Class", value: `${data.grade} ${data.section}` },
            { label: "Roll Number", value: data.rollNo },
            { label: "Attendance Rate", value: `${attendanceRate}%` },
          ].map((item) => (
            <div key={item.label} className="rounded-xl border border-slate-100 bg-slate-50 px-3 py-2">
              <p className="text-xs text-slate-500">{item.label}</p>
              <p className="mt-1 text-sm font-semibold text-slate-800">{item.value}</p>
            </div>
          ))}
        </div>
      </article>

      <div className="grid gap-4 lg:grid-cols-2">
        <article className="rounded-2xl border border-slate-200 bg-white p-5">
          <h3 className="inline-flex items-center gap-2 text-lg font-semibold text-slate-900">
            <CalendarDays className="h-5 w-5 text-slate-900" /> Weekly Timetable
          </h3>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-[400px] text-sm">
              <thead>
                <tr className="text-left text-slate-500">
                  <th className="py-2">Day</th>
                  <th className="py-2">Period</th>
                  <th className="py-2">Subject</th>
                  <th className="py-2">Teacher</th>
                </tr>
              </thead>
              <tbody>
                {data.timetable.map((item, idx) => (
                  <tr key={`${item.day}-${idx}`} className="border-t border-slate-100">
                    <td className="py-2">{item.day}</td>
                    <td className="py-2">{item.period}</td>
                    <td className="py-2 font-medium text-slate-700">{item.subject}</td>
                    <td className="py-2">{item.teacher}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </article>

        <article className="rounded-2xl border border-slate-200 bg-white p-5">
          <h3 className="inline-flex items-center gap-2 text-lg font-semibold text-slate-900">
            <BadgeCheck className="h-5 w-5 text-emerald-600" /> Attendance History
          </h3>
          <div className="mt-4 space-y-2">
            {data.attendanceHistory.map((item) => (
              <div key={item.date} className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50 px-3 py-2">
                <span className="text-sm text-slate-600">{formatDate(item.date)}</span>
                <span
                  className={`rounded-full px-2.5 py-1 text-xs font-semibold ${
                    item.present
                      ? item.late
                        ? "bg-amber-100 text-amber-700"
                        : "bg-emerald-100 text-emerald-700"
                      : "bg-slate-200 text-slate-700"
                  }`}
                >
                  {item.present ? (item.late ? "Late" : "Present") : "Absent"}
                </span>
              </div>
            ))}
          </div>
        </article>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <article className="rounded-2xl border border-slate-200 bg-white p-5">
          <h3 className="text-lg font-semibold text-slate-900">Grades & Report Card Insights</h3>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-[420px] text-sm">
              <thead>
                <tr className="text-left text-slate-500">
                  <th className="py-2">Subject</th>
                  <th className="py-2">Assessment</th>
                  <th className="py-2">Score</th>
                  <th className="py-2">Remarks</th>
                </tr>
              </thead>
              <tbody>
                {data.grades.map((grade, idx) => (
                  <tr key={`${grade.subject}-${idx}`} className="border-t border-slate-100">
                    <td className="py-2 font-medium text-slate-700">{grade.subject}</td>
                    <td className="py-2">{grade.assessment}</td>
                    <td className="py-2">{grade.marksObtained}/{grade.totalMarks}</td>
                    <td className="py-2">{grade.teacherRemarks}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <h4 className="mt-5 text-sm font-semibold text-slate-900">Term Report Cards</h4>
          {!canUseReportCards ? (
            <p className="mt-2 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-700">
              Standard report cards are locked on the Starter plan.
            </p>
          ) : null}
          <div className="mt-2 grid gap-2 sm:grid-cols-2">
            {(canUseReportCards ? data.termCards : []).map((term) => (
              <div key={term.termName} className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
                <p className="text-xs font-semibold text-slate-700">{term.termName}</p>
                <p className="mt-1 text-sm font-bold text-slate-900">{term.percentage}%</p>
                <p className="text-xs text-slate-600">Rank: {term.rank}</p>
                <p className="mt-1 text-xs text-slate-600">{term.remarks}</p>
              </div>
            ))}
          </div>
        </article>

        <article className="rounded-2xl border border-slate-200 bg-white p-5">
          <h3 className="inline-flex items-center gap-2 text-lg font-semibold text-slate-900">
            <ReceiptText className="h-5 w-5 text-slate-900" /> Fee Challan Status & Verification
          </h3>

          {!canUseDigitalChallans ? (
            <p className="mt-3 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-700">
              Digital challans and receipt verification are available from the Professional Campus plan.
            </p>
          ) : null}

          <div className="mt-3 space-y-2">
            {data.challans.map((challan) => (
              <div key={challan.month} className="rounded-xl border border-slate-100 bg-slate-50 px-3 py-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="text-sm font-semibold text-slate-700">{challan.month}</p>
                  <div className="flex items-center gap-2">
                    <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${challan.paid ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"}`}>
                      {challan.paid ? "Paid" : "Unpaid"}
                    </span>
                    <button
                      onClick={() => downloadChallan(challan.month)}
                      disabled={!canUseDigitalChallans}
                      className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <Download className="h-3.5 w-3.5" /> Download
                    </button>
                  </div>
                </div>
                <p className="mt-1 text-xs text-slate-600">{formatPkr(challan.amountPkr)} • Due {formatDate(challan.dueDate)}</p>
                <p className="text-xs text-slate-500">Challan: {challan.challanNo ?? "N/A"} • Branch: {challan.branchName ?? "N/A"}</p>
              </div>
            ))}
          </div>

          <div className="mt-4 rounded-xl border border-slate-200 bg-white p-3">
            <label className="text-xs font-medium text-slate-600">Verify with receipt ID</label>
            <div className="mt-2 flex gap-2">
              <input
                value={receiptQuery}
                onChange={(e) => {
                  const nextValue = e.target.value;
                  const normalized = nextValue.trim().toUpperCase();
                  setReceiptQuery(nextValue);

                  if (!normalized) {
                    setVerificationState("idle");
                    return;
                  }

                  const exists = data.challans.some((challan) => challan.receiptId?.toUpperCase() === normalized);
                  setVerificationState(exists ? "verified" : "not-found");
                }}
                placeholder="e.g. RCP-77812"
                className="w-full rounded-lg border border-slate-300 bg-slate-50 px-3 py-2 text-sm"
              />
              <button
                onClick={verifyReceipt}
                disabled={!canUseDigitalChallans}
                className="inline-flex items-center gap-1 rounded-lg bg-slate-900 px-3 py-2 text-xs font-semibold text-white disabled:cursor-not-allowed disabled:opacity-50"
              >
                <SearchCheck className="h-3.5 w-3.5" /> Check
              </button>
            </div>

            <div
              className={`mt-3 rounded-lg px-3 py-2 text-xs ${
                verificationState === "verified"
                  ? "border border-emerald-200 bg-emerald-50 text-emerald-700"
                  : verificationState === "not-found"
                    ? "border border-amber-200 bg-amber-50 text-amber-700"
                    : "border border-slate-200 bg-slate-50 text-slate-600"
              }`}
            >
              {verificationState === "verified" ? <CircleCheck className="mr-1 inline h-3.5 w-3.5" /> : <ShieldCheck className="mr-1 inline h-3.5 w-3.5" />}
              {verificationMessage}
            </div>
          </div>
        </article>
      </div>
    </div>
  );
}
