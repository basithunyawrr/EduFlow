"use client";

import type { ReactNode } from "react";
import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";
import { Building2, GraduationCap, LayoutDashboard, UsersRound } from "lucide-react";
import { tenants } from "@/lib/eduflow-data";

interface PortalFrameProps {
  role: "admin" | "teacher" | "parent";
  title: string;
  subtitle: string;
  children: ReactNode;
}

export function PortalFrame({ role, title, subtitle, children }: PortalFrameProps) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const tenant = searchParams.get("tenant") ?? tenants[0].slug;

  const navItems = [
    { href: "/admin", label: "Admin", roleKey: "admin", icon: LayoutDashboard },
    { href: "/teacher", label: "Teacher", roleKey: "teacher", icon: GraduationCap },
    { href: "/parent", label: "Student/Parent", roleKey: "parent", icon: UsersRound },
  ] as const;

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-sky-50 text-slate-800">
      <header className="border-b border-slate-200 bg-white/90 backdrop-blur">
        <div className="mx-auto flex w-full max-w-7xl flex-wrap items-center justify-between gap-4 px-4 py-4 md:px-8">
          <div>
            <Link href="/" className="text-lg font-bold text-slate-900">
              Edu<span className="text-amber-600">Flow</span>
            </Link>
            <p className="text-xs text-slate-500">Simple school operations for every role</p>
          </div>

          <div className="flex items-center gap-2 rounded-full border border-slate-200 bg-white p-1">
            {navItems.map((item) => {
              const active = role === item.roleKey || pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={`${item.href}?tenant=${tenant}`}
                  className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition ${
                    active ? "bg-slate-900 text-white" : "text-slate-600 hover:bg-slate-100"
                  }`}
                >
                  <item.icon className="h-3.5 w-3.5" />
                  {item.label}
                </Link>
              );
            })}
          </div>

          <div className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2">
            <Building2 className="h-4 w-4 text-slate-500" />
            <label htmlFor="tenant" className="text-xs font-medium text-slate-600">
              Tenant
            </label>
            <select
              id="tenant"
              value={tenant}
              onChange={(e) => {
                window.location.href = `${pathname}?tenant=${e.target.value}`;
              }}
              className="rounded-lg border border-slate-200 bg-slate-50 px-2 py-1 text-xs outline-none"
            >
              {tenants.map((t) => (
                <option key={t.slug} value={t.slug}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </header>

      <section className="mx-auto w-full max-w-7xl px-4 py-8 md:px-8">
        <h1 className="text-2xl font-bold text-slate-900">{title}</h1>
        <p className="mt-1 text-sm text-slate-600">{subtitle}</p>
        <div className="mt-6">{children}</div>
      </section>
    </div>
  );
}
