"use client";

import { useMemo, useState } from "react";
import { CheckCheck, NotebookPen, Save } from "lucide-react";
import type { AttendanceStatus, TeacherDashboardData, TeacherGradeInput } from "@/lib/eduflow-types";
import { getPlanLabel, planHasFeature } from "@/lib/authz";

interface TeacherDashboardProps {
  data: TeacherDashboardData;
}

interface ConfirmationModalState {
  open: boolean;
  title: string;
  description: string;
  onConfirm?: () => void;
}

export function TeacherDashboard({ data }: TeacherDashboardProps) {
  const [selectedClassId, setSelectedClassId] = useState(data.classes[0]?.id ?? "");
  const [homework, setHomework] = useState(data.homeworkDraft);
  const [publishMessage, setPublishMessage] = useState("");

  const plan = data.subscriptionPlan;
  const canUseHomeworkDiary = planHasFeature(plan, "homework_diary");
  const canUseStandardReportCards = planHasFeature(plan, "report_cards_standard");

  const selectedClass = useMemo(() => data.classes.find((item) => item.id === selectedClassId), [data.classes, selectedClassId]);
  const students = useMemo(() => selectedClass?.students ?? [], [selectedClass]);

  const [attendance, setAttendance] = useState<Record<string, AttendanceStatus>>(() => {
    const initialClass = data.classes[0];
    const initialStudents = initialClass?.students ?? [];
    return Object.fromEntries(initialStudents.map((student) => [student, "present"]));
  });

  const [examRows, setExamRows] = useState<TeacherGradeInput[]>(data.examDraft);
  const [examMessage, setExamMessage] = useState("");

  const [modalState, setModalState] = useState<ConfirmationModalState>({
    open: false,
    title: "",
    description: "",
  });

  function ensureAttendanceForClass(nextClassId: string) {
    const classRecord = data.classes.find((c) => c.id === nextClassId);
    if (!classRecord) return;

    setAttendance((prev) => {
      const next: Record<string, AttendanceStatus> = {};
      for (const student of classRecord.students) next[student] = prev[student] ?? "present";
      return next;
    });
  }

  function updateAttendance(student: string, status: AttendanceStatus) {
    setAttendance((prev) => ({ ...prev, [student]: status }));
  }

  function markAllPresent() {
    setAttendance(Object.fromEntries(students.map((student) => [student, "present"] as const)));
  }

  function attendanceCountBy(status: AttendanceStatus) {
    return students.filter((student) => attendance[student] === status).length;
  }

  function openPublishHomeworkModal() {
    if (!homework.trim()) {
      setPublishMessage("Please enter homework details before publishing.");
      return;
    }

    if (!canUseHomeworkDiary) {
      setPublishMessage("Homework/diary module is locked on the Starter plan.");
      return;
    }

    setModalState({
      open: true,
      title: "Publish Homework",
      description: `Are you sure you want to publish homework for ${selectedClass?.grade ?? "class"} ${selectedClass?.section ?? ""}?`,
      onConfirm: () => {
        setPublishMessage(`Homework posted for ${selectedClass?.grade ?? "class"} ${selectedClass?.section ?? ""}.`);
        setModalState({ open: false, title: "", description: "" });
      },
    });
  }

  function openSubmitExamModal() {
    if (!canUseStandardReportCards) {
      setExamMessage("Exam mark submission is locked on the Starter plan.");
      return;
    }

    setModalState({
      open: true,
      title: "Submit Exam Marks",
      description: `Submit ${examRows.length} exam mark entries for ${selectedClass?.grade ?? "class"}?`,
      onConfirm: () => {
        setExamMessage("Exam marks submitted successfully.");
        setModalState({ open: false, title: "", description: "" });
      },
    });
  }

  return (
    <div className="grid gap-6">
      <div className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-xs text-slate-700">
        Active Subscription: <span className="font-semibold">{getPlanLabel(plan)}</span>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-5">
        <h2 className="text-lg font-semibold text-slate-900">Class & Subject Management</h2>
        <div className="mt-3 flex flex-wrap items-center gap-3">
          <select
            value={selectedClassId}
            onChange={(e) => {
              setSelectedClassId(e.target.value);
              ensureAttendanceForClass(e.target.value);
            }}
            className="rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-sm"
          >
            {data.classes.map((cls) => (
              <option key={cls.id} value={cls.id}>
                {cls.grade} {cls.section} — {cls.subject}
              </option>
            ))}
          </select>
          <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-600">Strength: {selectedClass?.strength ?? 0}</span>
          <button
            onClick={markAllPresent}
            className="rounded-full border border-emerald-300 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700"
          >
            Mark All Present
          </button>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <article className="rounded-2xl border border-slate-200 bg-white p-5">
          <h3 className="text-lg font-semibold text-slate-900">Daily Attendance</h3>
          <p className="mt-1 text-xs text-slate-500">Tap Present, Absent, or Late for each student.</p>

          <div className="mt-3 grid gap-2 sm:grid-cols-3">
            <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-semibold text-emerald-700">Present: {attendanceCountBy("present")}</div>
            <div className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-700">Absent: {attendanceCountBy("absent")}</div>
            <div className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-semibold text-amber-700">Late: {attendanceCountBy("late")}</div>
          </div>

          <div className="mt-4 space-y-2">
            {students.map((student) => (
              <div key={student} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-100 p-3">
                <span className="text-sm font-medium text-slate-700">{student}</span>
                <div className="flex gap-2 text-xs">
                  {(["present", "absent", "late"] as const).map((status) => {
                    const active = attendance[student] === status;
                    return (
                      <button
                        key={status}
                        onClick={() => updateAttendance(student, status)}
                        className={`rounded-full px-3 py-1 font-semibold capitalize transition ${
                          active
                            ? status === "present"
                              ? "bg-emerald-600 text-white"
                              : status === "absent"
                                ? "bg-slate-700 text-white"
                                : "bg-amber-500 text-white"
                            : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                        }`}
                      >
                        {status}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </article>

        <article className="rounded-2xl border border-slate-200 bg-white p-5">
          <h3 className="inline-flex items-center gap-2 text-lg font-semibold text-slate-900">
            <NotebookPen className="h-5 w-5 text-slate-900" /> Homework & Grade Management
          </h3>

          <textarea
            value={homework}
            onChange={(e) => setHomework(e.target.value)}
            rows={4}
            className="mt-3 w-full rounded-xl border border-slate-300 bg-slate-50 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-200"
          />
          <button
            onClick={openPublishHomeworkModal}
            disabled={!canUseHomeworkDiary}
            className="mt-2 inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <CheckCheck className="h-4 w-4" /> Publish Homework
          </button>
          {publishMessage ? <p className="mt-2 text-xs text-emerald-700">{publishMessage}</p> : null}
          {!canUseHomeworkDiary ? <p className="mt-2 text-xs text-amber-700">Homework/diary module unlocks on Professional Campus and above.</p> : null}

          <h4 className="mt-5 text-sm font-semibold text-slate-900">Exam Marks Submission</h4>
          <div className="mt-2 overflow-x-auto">
            <table className="w-full min-w-[480px] text-sm">
              <thead>
                <tr className="text-left text-slate-500">
                  <th className="py-2">Student</th>
                  <th className="py-2">Assessment</th>
                  <th className="py-2">Marks</th>
                  <th className="py-2">Total</th>
                </tr>
              </thead>
              <tbody>
                {examRows.map((row) => (
                  <tr key={row.id} className="border-t border-slate-100">
                    <td className="py-2 text-slate-700">{row.studentName}</td>
                    <td className="py-2 text-slate-700">{row.assessment}</td>
                    <td className="py-2">
                      <input
                        type="number"
                        value={row.marks}
                        onChange={(e) => setExamRows((prev) => prev.map((item) => (item.id === row.id ? { ...item, marks: Number(e.target.value) } : item)))}
                        className="w-20 rounded-lg border border-slate-300 bg-slate-50 px-2 py-1"
                      />
                    </td>
                    <td className="py-2">
                      <input
                        type="number"
                        value={row.total}
                        onChange={(e) => setExamRows((prev) => prev.map((item) => (item.id === row.id ? { ...item, total: Number(e.target.value) } : item)))}
                        className="w-20 rounded-lg border border-slate-300 bg-slate-50 px-2 py-1"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <button
            onClick={openSubmitExamModal}
            disabled={!canUseStandardReportCards}
            className="mt-3 inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Save className="h-4 w-4" /> Submit Exam Marks
          </button>
          {examMessage ? <p className="mt-2 text-xs text-emerald-700">{examMessage}</p> : null}
          {!canUseStandardReportCards ? <p className="mt-2 text-xs text-amber-700">Standard report card workflow is unavailable on Starter plan.</p> : null}
        </article>
      </div>

      {modalState.open ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 px-4">
          <div className="w-full max-w-md rounded-2xl bg-white p-5 shadow-2xl">
            <h3 className="text-lg font-semibold text-slate-900">{modalState.title}</h3>
            <p className="mt-2 text-sm text-slate-600">{modalState.description}</p>
            <div className="mt-4 flex justify-end gap-2">
              <button onClick={() => setModalState({ open: false, title: "", description: "" })} className="rounded-xl border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700">Cancel</button>
              <button onClick={() => modalState.onConfirm?.()} className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white">Confirm</button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
