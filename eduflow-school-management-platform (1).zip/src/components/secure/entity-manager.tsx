"use client";

import { useEffect, useMemo, useState } from "react";
import type { AuthRole } from "@/lib/authz";

type EntityType = "school" | "school_admin" | "teacher" | "parent" | "student" | "fee_challan";

interface EntityManagerProps {
  actorRole: AuthRole;
  defaultTenantSlug?: string;
}

interface TenantStudent {
  id: string;
  fullName: string;
  grade: string;
  section: string;
  rollNo: string;
}

interface TenantStateResponse {
  ok: boolean;
  tenant?: {
    id: string;
    slug: string;
    name: string;
    city: string;
    subscriptionPlan: string;
  };
  students?: TenantStudent[];
}

const entityChoicesByRole: Record<AuthRole, EntityType[]> = {
  super_admin: ["school", "school_admin", "teacher", "parent", "student", "fee_challan"],
  school_admin: ["school", "teacher", "parent", "student", "fee_challan"],
  teacher: ["parent", "student"],
  parent: [],
};

export function EntityManager({ actorRole, defaultTenantSlug }: EntityManagerProps) {
  const choices = entityChoicesByRole[actorRole];
  const [entityType, setEntityType] = useState<EntityType>(choices[0] ?? "student");

  const [tenantSlug, setTenantSlug] = useState(defaultTenantSlug ?? "");
  const [schoolName, setSchoolName] = useState("");
  const [city, setCity] = useState("");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("TempPass@123");
  const [phone, setPhone] = useState("");
  const [grade, setGrade] = useState("Grade 1");
  const [section, setSection] = useState("A");
  const [rollNo, setRollNo] = useState("");
  const [studentId, setStudentId] = useState("");
  const [monthLabel, setMonthLabel] = useState("August 2026");
  const [amountPkr, setAmountPkr] = useState(5000);
  const [dueDate, setDueDate] = useState("2026-08-10");

  const [students, setStudents] = useState<TenantStudent[]>([]);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const needsTenantState = entityType === "student" || entityType === "fee_challan";

  useEffect(() => {
    if (!needsTenantState) return;

    async function loadState() {
      const query = tenantSlug ? `?tenant=${tenantSlug}` : "";
      const res = await fetch(`/api/management/tenant-state${query}`);
      const payload = (await res.json()) as TenantStateResponse;
      if (!res.ok || !payload.ok) return;

      const items = payload.students ?? [];
      setStudents(items);
      if (items.length > 0 && !studentId) setStudentId(items[0].id);
    }

    void loadState();
  }, [needsTenantState, tenantSlug, studentId]);

  const title = useMemo(() => {
    if (actorRole === "super_admin") return "God Mode Entity Management";
    if (actorRole === "school_admin") return "School Management Console";
    if (actorRole === "teacher") return "Class Management Console";
    return "Limited Access";
  }, [actorRole]);

  if (choices.length === 0) {
    return (
      <article className="rounded-2xl border border-slate-200 bg-white p-5">
        <h2 className="text-lg font-semibold text-slate-900">No write permissions</h2>
        <p className="mt-2 text-sm text-slate-600">Your role has read-only access.</p>
      </article>
    );
  }

  async function submitEntity() {
    setLoading(true);
    setMessage("");

    try {
      const payload: Record<string, unknown> = {
        entityType,
        tenantSlug,
      };

      if (entityType === "school") {
        payload.schoolName = schoolName;
        payload.city = city;
      }

      if (entityType === "school_admin" || entityType === "teacher" || entityType === "parent") {
        payload.fullName = fullName;
        payload.email = email;
        payload.password = password;
        payload.phone = phone;
      }

      if (entityType === "student") {
        payload.fullName = fullName;
        payload.grade = grade;
        payload.section = section;
        payload.rollNo = rollNo;
      }

      if (entityType === "fee_challan") {
        payload.studentId = studentId;
        payload.monthLabel = monthLabel;
        payload.amountPkr = amountPkr;
        payload.dueDate = dueDate;
      }

      const res = await fetch("/api/management/create-entity", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const result = (await res.json()) as { ok: boolean; message?: string };
      setMessage(result.message ?? (result.ok ? "Created successfully." : "Failed to create."));
    } catch {
      setMessage("Request failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <article className="rounded-2xl border border-slate-200 bg-white p-5">
      <h2 className="text-lg font-semibold text-slate-900">{title}</h2>

      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <label className="text-xs font-semibold text-slate-600">
          Entity Type
          <select
            value={entityType}
            onChange={(e) => setEntityType(e.target.value as EntityType)}
            className="mt-1 w-full rounded-lg border border-slate-300 bg-slate-50 px-2 py-2 text-sm"
          >
            {choices.map((choice) => (
              <option key={choice} value={choice}>
                {choice.replaceAll("_", " ")}
              </option>
            ))}
          </select>
        </label>

        {actorRole === "super_admin" ? (
          <label className="text-xs font-semibold text-slate-600">
            Tenant Slug
            <input
              value={tenantSlug}
              onChange={(e) => setTenantSlug(e.target.value)}
              placeholder="al-noor"
              className="mt-1 w-full rounded-lg border border-slate-300 bg-slate-50 px-2 py-2 text-sm"
            />
          </label>
        ) : null}
      </div>

      {entityType === "school" ? (
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <input value={schoolName} onChange={(e) => setSchoolName(e.target.value)} placeholder="School Name" className="rounded-lg border border-slate-300 bg-slate-50 px-3 py-2 text-sm" />
          <input value={city} onChange={(e) => setCity(e.target.value)} placeholder="City" className="rounded-lg border border-slate-300 bg-slate-50 px-3 py-2 text-sm" />
        </div>
      ) : null}

      {(entityType === "school_admin" || entityType === "teacher" || entityType === "parent") ? (
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <input value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Full Name" className="rounded-lg border border-slate-300 bg-slate-50 px-3 py-2 text-sm" />
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="rounded-lg border border-slate-300 bg-slate-50 px-3 py-2 text-sm" />
          <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" className="rounded-lg border border-slate-300 bg-slate-50 px-3 py-2 text-sm" />
          <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Phone" className="rounded-lg border border-slate-300 bg-slate-50 px-3 py-2 text-sm" />
        </div>
      ) : null}

      {entityType === "student" ? (
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <input value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Student Name" className="rounded-lg border border-slate-300 bg-slate-50 px-3 py-2 text-sm" />
          <input value={grade} onChange={(e) => setGrade(e.target.value)} placeholder="Grade" className="rounded-lg border border-slate-300 bg-slate-50 px-3 py-2 text-sm" />
          <input value={section} onChange={(e) => setSection(e.target.value)} placeholder="Section" className="rounded-lg border border-slate-300 bg-slate-50 px-3 py-2 text-sm" />
          <input value={rollNo} onChange={(e) => setRollNo(e.target.value)} placeholder="Roll No" className="rounded-lg border border-slate-300 bg-slate-50 px-3 py-2 text-sm" />
        </div>
      ) : null}

      {entityType === "fee_challan" ? (
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <select value={studentId} onChange={(e) => setStudentId(e.target.value)} className="rounded-lg border border-slate-300 bg-slate-50 px-2 py-2 text-sm">
            {students.map((student) => (
              <option key={student.id} value={student.id}>{student.fullName} ({student.rollNo})</option>
            ))}
          </select>
          <input value={monthLabel} onChange={(e) => setMonthLabel(e.target.value)} placeholder="Month label" className="rounded-lg border border-slate-300 bg-slate-50 px-3 py-2 text-sm" />
          <input type="number" value={amountPkr} onChange={(e) => setAmountPkr(Number(e.target.value))} placeholder="Amount" className="rounded-lg border border-slate-300 bg-slate-50 px-3 py-2 text-sm" />
          <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className="rounded-lg border border-slate-300 bg-slate-50 px-3 py-2 text-sm" />
        </div>
      ) : null}

      <button
        onClick={submitEntity}
        disabled={loading}
        className="mt-4 rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"
      >
        {loading ? "Submitting..." : "Create"}
      </button>

      {message ? <p className="mt-2 text-xs text-slate-700">{message}</p> : null}
    </article>
  );
}
