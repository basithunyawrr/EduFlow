import Link from "next/link";
import type { ReactNode } from "react";
import type { SessionUser } from "@/lib/auth-session";
import { LogoutButton } from "@/components/auth/logout-button";

interface SecureFrameProps {
  user: SessionUser;
  title: string;
  subtitle: string;
  children: ReactNode;
}

function roleLabel(role: SessionUser["role"]) {
  if (role === "super_admin") return "Super Admin";
  if (role === "school_admin") return "School Admin";
  if (role === "teacher") return "Teacher";
  return "Parent";
}

export function SecureFrame({ user, title, subtitle, children }: SecureFrameProps) {
  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-sky-50 text-slate-800">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex w-full max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-4 md:px-8">
          <div>
            <Link href="/" className="text-lg font-bold text-slate-900">
              Edu<span className="text-amber-600">Flow</span>
            </Link>
            <p className="text-xs text-slate-500">Authenticated workspace</p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Link href="/dashboard" className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold text-slate-700">
              My Dashboard
            </Link>
            <Link href="/portal" className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold text-slate-700">
              Public Demo Portals
            </Link>
            <LogoutButton />
          </div>
        </div>
      </header>

      <section className="mx-auto w-full max-w-7xl px-4 py-7 md:px-8">
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">
            Logged in as <span className="font-semibold text-slate-700">{user.email}</span> ({roleLabel(user.role)})
          </p>
          <h1 className="mt-2 text-2xl font-bold text-slate-900">{title}</h1>
          <p className="mt-1 text-sm text-slate-600">{subtitle}</p>
        </div>

        <div className="mt-5">{children}</div>
      </section>
    </main>
  );
}
