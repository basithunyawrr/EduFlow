import { pbkdf2 as pbkdf2Callback, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";

const pbkdf2 = promisify(pbkdf2Callback);
const PBKDF2_ITERATIONS = 120_000;
const KEY_LENGTH = 64;
const DIGEST = "sha512";

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const derived = await pbkdf2(password, salt, PBKDF2_ITERATIONS, KEY_LENGTH, DIGEST);
  return `pbkdf2$${PBKDF2_ITERATIONS}$${salt}$${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, storedHash: string): Promise<boolean> {
  const [algorithm, iterationsRaw, salt, hashHex] = storedHash.split("$");
  if (algorithm !== "pbkdf2" || !iterationsRaw || !salt || !hashHex) return false;

  const iterations = Number(iterationsRaw);
  if (!Number.isFinite(iterations) || iterations <= 0) return false;

  const originalBuffer = Buffer.from(hashHex, "hex");
  const comparison = await pbkdf2(password, salt, iterations, originalBuffer.length, DIGEST);

  if (comparison.length !== originalBuffer.length) return false;
  return timingSafeEqual(comparison, originalBuffer);
}
