import { createHash, randomBytes } from "crypto";
import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { authSessions, authUsers, roleAuditLogs, tenants } from "@/db/schema";
import { hashPassword } from "@/lib/auth-crypto";
import type { AuthRole, SubscriptionPlan } from "@/lib/authz";

export const SESSION_COOKIE_NAME = "eduflow_session";

const SESSION_MAX_AGE_SECONDS = 60 * 60 * 24 * 7;

interface SeedUser {
  fullName: string;
  email: string;
  password: string;
  role: AuthRole;
  tenantSlug?: string;
}

export interface SessionUser {
  id: string;
  fullName: string;
  email: string;
  role: AuthRole;
  tenantId: string | null;
  tenantSlug: string | null;
  tenantName: string | null;
  subscriptionPlan: SubscriptionPlan | null;
}

function hashSessionToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

function mapPlan(input: string | null): SubscriptionPlan | null {
  if (!input) return null;
  if (input === "starter" || input === "professional" || input === "enterprise") {
    return input;
  }
  return null;
}

function mapRole(input: string): AuthRole {
  if (input === "super_admin" || input === "school_admin" || input === "teacher" || input === "parent") {
    return input;
  }
  return "parent";
}

export async function ensureAuthSeedData() {
  const tenantSeeds = [
    { slug: "al-noor", name: "Al-Noor Grammar School", city: "Lahore", subscriptionPlan: "starter" },
    { slug: "city-education", name: "City Education Campus", city: "Karachi", subscriptionPlan: "professional" },
    { slug: "iqra-academy", name: "Iqra Academy", city: "Islamabad", subscriptionPlan: "enterprise" },
  ] as const;

  for (const tenantSeed of tenantSeeds) {
    const existing = await db.select().from(tenants).where(eq(tenants.slug, tenantSeed.slug)).limit(1);
    if (existing.length === 0) {
      await db.insert(tenants).values({
        slug: tenantSeed.slug,
        name: tenantSeed.name,
        city: tenantSeed.city,
        subscriptionPlan: tenantSeed.subscriptionPlan,
      });
    } else {
      await db
        .update(tenants)
        .set({
          name: tenantSeed.name,
          city: tenantSeed.city,
          subscriptionPlan: tenantSeed.subscriptionPlan,
        })
        .where(eq(tenants.id, existing[0].id));
    }
  }

  const superAdminEmail = process.env.SUPER_ADMIN_EMAIL ?? "superadmin@eduflow.pk";
  const superAdminPassword = process.env.SUPER_ADMIN_PASSWORD ?? "SuperAdmin@123";

  const seedUsers: SeedUser[] = [
    {
      fullName: "EduFlow Super Admin",
      email: superAdminEmail,
      password: superAdminPassword,
      role: "super_admin",
    },
    {
      fullName: "Ayesha Khan",
      email: "admin.alnoor@eduflow.pk",
      password: "SchoolAdmin@123",
      role: "school_admin",
      tenantSlug: "al-noor",
    },
    {
      fullName: "Bilal Aslam",
      email: "teacher.alnoor@eduflow.pk",
      password: "Teacher@123",
      role: "teacher",
      tenantSlug: "al-noor",
    },
    {
      fullName: "Hamza Tariq",
      email: "parent.alnoor@eduflow.pk",
      password: "Parent@123",
      role: "parent",
      tenantSlug: "al-noor",
    },
  ];

  for (const seedUser of seedUsers) {
    const existing = await db.select().from(authUsers).where(eq(authUsers.email, seedUser.email)).limit(1);
    if (existing.length > 0) continue;

    const tenantRecord = seedUser.tenantSlug
      ? (await db.select().from(tenants).where(eq(tenants.slug, seedUser.tenantSlug)).limit(1))[0]
      : undefined;

    const passwordHash = await hashPassword(seedUser.password);
    await db.insert(authUsers).values({
      fullName: seedUser.fullName,
      email: seedUser.email,
      role: seedUser.role,
      passwordHash,
      tenantId: tenantRecord?.id,
      isActive: true,
    });
  }
}

export async function createSession(userId: string): Promise<string> {
  const rawToken = randomBytes(32).toString("hex");
  const tokenHash = hashSessionToken(rawToken);

  const expiresAt = new Date(Date.now() + SESSION_MAX_AGE_SECONDS * 1000);

  await db.insert(authSessions).values({
    userId,
    tokenHash,
    expiresAt,
  });

  return rawToken;
}

export async function setSessionCookie(token: string) {
  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: SESSION_MAX_AGE_SECONDS,
    path: "/",
  });
}

export async function clearSessionCookie() {
  const cookieStore = await cookies();
  cookieStore.delete(SESSION_COOKIE_NAME);
}

export async function getSessionUser(): Promise<SessionUser | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE_NAME)?.value;
  if (!token) return null;

  const tokenHash = hashSessionToken(token);

  const rows = await db
    .select({
      sessionId: authSessions.id,
      userId: authUsers.id,
      fullName: authUsers.fullName,
      email: authUsers.email,
      role: authUsers.role,
      isActive: authUsers.isActive,
      tenantId: authUsers.tenantId,
      tenantSlug: tenants.slug,
      tenantName: tenants.name,
      subscriptionPlan: tenants.subscriptionPlan,
    })
    .from(authSessions)
    .innerJoin(authUsers, eq(authSessions.userId, authUsers.id))
    .leftJoin(tenants, eq(authUsers.tenantId, tenants.id))
    .where(and(eq(authSessions.tokenHash, tokenHash), gt(authSessions.expiresAt, new Date())))
    .limit(1);

  const row = rows[0];
  if (!row || !row.isActive) return null;

  await db
    .update(authSessions)
    .set({ lastSeenAt: new Date() })
    .where(eq(authSessions.id, row.sessionId));

  return {
    id: row.userId,
    fullName: row.fullName,
    email: row.email,
    role: mapRole(row.role),
    tenantId: row.tenantId,
    tenantSlug: row.tenantSlug ?? null,
    tenantName: row.tenantName ?? null,
    subscriptionPlan: mapPlan(row.subscriptionPlan),
  };
}

export async function requireSessionUser(roles?: AuthRole[]): Promise<SessionUser> {
  const sessionUser = await getSessionUser();
  if (!sessionUser) {
    redirect("/login");
  }

  if (roles && roles.length > 0 && !roles.includes(sessionUser.role)) {
    redirect("/dashboard");
  }

  return sessionUser;
}

export async function logRoleAction(params: {
  actorUserId: string;
  tenantId?: string | null;
  action: string;
  details?: string;
}) {
  await db.insert(roleAuditLogs).values({
    actorUserId: params.actorUserId,
    tenantId: params.tenantId ?? null,
    action: params.action,
    details: params.details,
  });
}
