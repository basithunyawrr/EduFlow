export type AuthRole = "super_admin" | "school_admin" | "teacher" | "parent";

export type SubscriptionPlan = "starter" | "professional" | "enterprise";

export type PermissionKey =
  | "manage_all_tenants"
  | "create_school"
  | "create_school_admin"
  | "create_teacher"
  | "create_parent"
  | "create_student"
  | "mark_attendance"
  | "upload_grades"
  | "publish_homework"
  | "generate_fee_challan"
  | "verify_fee_receipts"
  | "view_child_reports"
  | "view_analytics"
  | "manage_multi_campus"
  | "send_automated_reminders";

export type FeatureKey =
  | "student_directory_basic"
  | "attendance_basic"
  | "fee_challans_digital"
  | "homework_diary"
  | "report_cards_standard"
  | "analytics_advanced"
  | "multi_campus_tracking"
  | "automated_sms_reminders";

const rolePermissions: Record<AuthRole, PermissionKey[]> = {
  super_admin: [
    "manage_all_tenants",
    "create_school",
    "create_school_admin",
    "create_teacher",
    "create_parent",
    "create_student",
    "mark_attendance",
    "upload_grades",
    "publish_homework",
    "generate_fee_challan",
    "verify_fee_receipts",
    "view_child_reports",
    "view_analytics",
    "manage_multi_campus",
    "send_automated_reminders",
  ],
  school_admin: [
    "create_school",
    "create_teacher",
    "create_parent",
    "create_student",
    "generate_fee_challan",
    "verify_fee_receipts",
    "view_child_reports",
    "view_analytics",
    "send_automated_reminders",
  ],
  teacher: [
    "create_parent",
    "create_student",
    "mark_attendance",
    "upload_grades",
    "publish_homework",
    "view_child_reports",
  ],
  parent: ["verify_fee_receipts", "view_child_reports"],
};

const planFeatureMap: Record<SubscriptionPlan, FeatureKey[]> = {
  starter: ["student_directory_basic", "attendance_basic"],
  professional: [
    "student_directory_basic",
    "attendance_basic",
    "fee_challans_digital",
    "homework_diary",
    "report_cards_standard",
  ],
  enterprise: [
    "student_directory_basic",
    "attendance_basic",
    "fee_challans_digital",
    "homework_diary",
    "report_cards_standard",
    "analytics_advanced",
    "multi_campus_tracking",
    "automated_sms_reminders",
  ],
};

export function getRolePermissions(role: AuthRole): PermissionKey[] {
  return rolePermissions[role];
}

export function hasPermission(role: AuthRole, permission: PermissionKey): boolean {
  return rolePermissions[role].includes(permission);
}

export function planHasFeature(plan: SubscriptionPlan, feature: FeatureKey): boolean {
  return planFeatureMap[plan].includes(feature);
}

export function getPlanLabel(plan: SubscriptionPlan): string {
  if (plan === "starter") return "Starter";
  if (plan === "professional") return "Professional Campus";
  return "Enterprise Network";
}
