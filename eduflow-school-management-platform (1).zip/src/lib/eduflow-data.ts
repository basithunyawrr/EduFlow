import type {
  AdminDashboardData,
  ParentDashboardData,
  TeacherDashboardData,
  Tenant,
} from "@/lib/eduflow-types";

export const tenants: Tenant[] = [
  {
    id: "t-1",
    slug: "al-noor",
    name: "Al-Noor Grammar School",
    city: "Lahore",
    totalStudents: 1280,
    totalTeachers: 74,
    monthlyRevenuePkr: 4860000,
    subscriptionPlan: "starter",
  },
  {
    id: "t-2",
    slug: "city-education",
    name: "City Education Campus",
    city: "Karachi",
    totalStudents: 910,
    totalTeachers: 52,
    monthlyRevenuePkr: 3320000,
    subscriptionPlan: "professional",
  },
  {
    id: "t-3",
    slug: "iqra-academy",
    name: "Iqra Academy",
    city: "Islamabad",
    totalStudents: 640,
    totalTeachers: 39,
    monthlyRevenuePkr: 2210000,
    subscriptionPlan: "enterprise",
  },
];

const adminDataByTenant: Record<string, AdminDashboardData> = {
  "al-noor": {
    tenant: tenants[0],
    activeStudents: 1244,
    activeTeachers: 71,
    monthlyCollectionPkr: 4585000,
    attendanceTodayPercent: 93,
    pendingFeesPkr: 429000,
    users: [
      { name: "Ayesha Khan", role: "school_admin", status: "active" },
      { name: "Bilal Aslam", role: "teacher", status: "active" },
      { name: "Sara Amjad", role: "teacher", status: "invited" },
      { name: "Hamza Tariq", role: "parent", status: "active" },
    ],
    feeCollections: [
      { id: "fc-1", month: "Aug 2026", classLabel: "Grade 7", amountPkr: 740000, paidPkr: 690000, pendingPkr: 50000, status: "healthy" },
      { id: "fc-2", month: "Aug 2026", classLabel: "Grade 8", amountPkr: 710000, paidPkr: 610000, pendingPkr: 100000, status: "at-risk" },
      { id: "fc-3", month: "Aug 2026", classLabel: "Grade 9", amountPkr: 780000, paidPkr: 730000, pendingPkr: 50000, status: "healthy" },
      { id: "fc-4", month: "Jul 2026", classLabel: "Grade 7", amountPkr: 740000, paidPkr: 722000, pendingPkr: 18000, status: "healthy" },
    ],
  },
  "city-education": {
    tenant: tenants[1],
    activeStudents: 880,
    activeTeachers: 49,
    monthlyCollectionPkr: 3090000,
    attendanceTodayPercent: 90,
    pendingFeesPkr: 366000,
    users: [
      { name: "Nadia Rauf", role: "school_admin", status: "active" },
      { name: "Ali Hamid", role: "teacher", status: "active" },
      { name: "Sadia Danish", role: "parent", status: "active" },
    ],
    feeCollections: [
      { id: "fc-5", month: "Aug 2026", classLabel: "Grade 6", amountPkr: 540000, paidPkr: 470000, pendingPkr: 70000, status: "at-risk" },
      { id: "fc-6", month: "Aug 2026", classLabel: "Grade 5", amountPkr: 510000, paidPkr: 490000, pendingPkr: 20000, status: "healthy" },
      { id: "fc-7", month: "Jul 2026", classLabel: "Grade 6", amountPkr: 540000, paidPkr: 525000, pendingPkr: 15000, status: "healthy" },
    ],
  },
  "iqra-academy": {
    tenant: tenants[2],
    activeStudents: 618,
    activeTeachers: 37,
    monthlyCollectionPkr: 2040000,
    attendanceTodayPercent: 95,
    pendingFeesPkr: 172000,
    users: [
      { name: "Mariam Akhtar", role: "school_admin", status: "active" },
      { name: "Usman Javed", role: "teacher", status: "active" },
      { name: "Fiza Noor", role: "parent", status: "invited" },
    ],
    feeCollections: [
      { id: "fc-8", month: "Aug 2026", classLabel: "Grade 9", amountPkr: 495000, paidPkr: 465000, pendingPkr: 30000, status: "healthy" },
      { id: "fc-9", month: "Aug 2026", classLabel: "Grade 10", amountPkr: 520000, paidPkr: 480000, pendingPkr: 40000, status: "at-risk" },
    ],
  },
};

const teacherDataByTenant: Record<string, TeacherDashboardData> = {
  "al-noor": {
    teacherName: "Bilal Aslam",
    tenantSlug: "al-noor",
    subscriptionPlan: "starter",
    classes: [
      {
        id: "c-1",
        grade: "Grade 7",
        section: "A",
        subject: "Mathematics",
        strength: 34,
        students: ["Areeba", "Hassan", "Maham", "Talha", "Yusra", "Zoya", "Abdullah", "Eman"],
      },
      {
        id: "c-2",
        grade: "Grade 8",
        section: "B",
        subject: "Mathematics",
        strength: 31,
        students: ["Aiman", "Burhan", "Dua", "Fatima", "Hamna", "Ilyas", "Jannat", "Kashif"],
      },
    ],
    homeworkDraft: "Complete chapter 5 exercises 1-10 and revise fractions.",
    gradebook: [
      { subject: "Mathematics", assessment: "Quiz 1", marksObtained: 17, totalMarks: 20, teacherRemarks: "Strong effort" },
      { subject: "Mathematics", assessment: "Assignment", marksObtained: 44, totalMarks: 50, teacherRemarks: "Neat work" },
    ],
    examDraft: [
      { id: "eg-1", studentName: "Areeba", assessment: "Unit Test", marks: 18, total: 20 },
      { id: "eg-2", studentName: "Hassan", assessment: "Unit Test", marks: 16, total: 20 },
      { id: "eg-3", studentName: "Maham", assessment: "Unit Test", marks: 19, total: 20 },
    ],
  },
  "city-education": {
    teacherName: "Ali Hamid",
    tenantSlug: "city-education",
    subscriptionPlan: "professional",
    classes: [
      {
        id: "c-3",
        grade: "Grade 6",
        section: "C",
        subject: "Science",
        strength: 29,
        students: ["Hiba", "Inaya", "Junaid", "Laiba", "Muneeb", "Noor", "Rafay", "Sahar"],
      },
    ],
    homeworkDraft: "Read pages 12-18 and make a diagram of the water cycle.",
    gradebook: [
      { subject: "Science", assessment: "Lab Activity", marksObtained: 18, totalMarks: 20, teacherRemarks: "Great curiosity" },
      { subject: "Science", assessment: "Worksheet", marksObtained: 25, totalMarks: 30, teacherRemarks: "Can improve labeling" },
    ],
    examDraft: [
      { id: "eg-4", studentName: "Hiba", assessment: "Chapter Test", marks: 14, total: 20 },
      { id: "eg-5", studentName: "Inaya", assessment: "Chapter Test", marks: 17, total: 20 },
    ],
  },
  "iqra-academy": {
    teacherName: "Usman Javed",
    tenantSlug: "iqra-academy",
    subscriptionPlan: "enterprise",
    classes: [
      {
        id: "c-4",
        grade: "Grade 9",
        section: "A",
        subject: "English",
        strength: 26,
        students: ["Aiman", "Basit", "Daniya", "Faizan", "Hoor", "Iqra", "Kiran", "Maaz"],
      },
    ],
    homeworkDraft: "Write a 250-word reflection on your favorite story.",
    gradebook: [
      { subject: "English", assessment: "Comprehension", marksObtained: 16, totalMarks: 20, teacherRemarks: "Excellent summary" },
      { subject: "English", assessment: "Essay", marksObtained: 23, totalMarks: 30, teacherRemarks: "Good vocabulary" },
    ],
    examDraft: [
      { id: "eg-6", studentName: "Aiman", assessment: "Narrative Essay", marks: 20, total: 25 },
      { id: "eg-7", studentName: "Basit", assessment: "Narrative Essay", marks: 17, total: 25 },
    ],
  },
};

const parentDataByTenant: Record<string, ParentDashboardData> = {
  "al-noor": {
    studentName: "Ahmed Tariq",
    grade: "Grade 7",
    section: "A",
    rollNo: "A-17",
    tenantSlug: "al-noor",
    subscriptionPlan: "starter",
    timetable: [
      { day: "Monday", period: "08:00-08:45", subject: "Math", teacher: "Bilal Aslam" },
      { day: "Monday", period: "09:00-09:45", subject: "Science", teacher: "Zainab Riaz" },
      { day: "Tuesday", period: "08:00-08:45", subject: "English", teacher: "Usman Javed" },
      { day: "Wednesday", period: "10:00-10:45", subject: "Urdu", teacher: "Sana Imran" },
    ],
    attendanceHistory: [
      { date: "2026-08-18", present: true, late: false },
      { date: "2026-08-19", present: true, late: true },
      { date: "2026-08-20", present: false, late: false },
      { date: "2026-08-21", present: true, late: false },
    ],
    grades: [
      { subject: "Math", assessment: "Mid-Term", marksObtained: 78, totalMarks: 100, teacherRemarks: "Excellent progress" },
      { subject: "Science", assessment: "Quiz", marksObtained: 17, totalMarks: 20, teacherRemarks: "Well prepared" },
      { subject: "English", assessment: "Essay", marksObtained: 22, totalMarks: 30, teacherRemarks: "Good expression" },
    ],
    termCards: [
      { termName: "Term 1", percentage: 83, rank: "5th / 34", remarks: "Consistent and focused" },
      { termName: "Term 2", percentage: 86, rank: "3rd / 34", remarks: "Improved mathematics significantly" },
    ],
    challans: [
      {
        month: "July 2026",
        amountPkr: 13500,
        dueDate: "2026-07-10",
        paid: true,
        receiptId: "RCP-77812",
        challanNo: "CH-ALN-0726-17",
        branchName: "HBL Main Boulevard",
      },
      {
        month: "August 2026",
        amountPkr: 13500,
        dueDate: "2026-08-10",
        paid: false,
        challanNo: "CH-ALN-0826-17",
        branchName: "Meezan Bank Johar Town",
      },
    ],
  },
  "city-education": {
    studentName: "Hiba Danish",
    grade: "Grade 6",
    section: "C",
    rollNo: "C-08",
    tenantSlug: "city-education",
    subscriptionPlan: "professional",
    timetable: [
      { day: "Monday", period: "08:00-08:45", subject: "Science", teacher: "Ali Hamid" },
      { day: "Tuesday", period: "09:00-09:45", subject: "Math", teacher: "Nida Javed" },
    ],
    attendanceHistory: [
      { date: "2026-08-18", present: true, late: false },
      { date: "2026-08-19", present: true, late: false },
    ],
    grades: [{ subject: "Science", assessment: "Lab", marksObtained: 18, totalMarks: 20, teacherRemarks: "Excellent observation" }],
    termCards: [{ termName: "Term 1", percentage: 88, rank: "2nd / 29", remarks: "Great in practical learning" }],
    challans: [
      {
        month: "August 2026",
        amountPkr: 12000,
        dueDate: "2026-08-09",
        paid: true,
        receiptId: "RCP-50119",
        challanNo: "CH-CED-0826-08",
        branchName: "Bank Alfalah Clifton",
      },
    ],
  },
  "iqra-academy": {
    studentName: "Aiman Noor",
    grade: "Grade 9",
    section: "A",
    rollNo: "A-04",
    tenantSlug: "iqra-academy",
    subscriptionPlan: "enterprise",
    timetable: [
      { day: "Monday", period: "10:00-10:45", subject: "English", teacher: "Usman Javed" },
      { day: "Thursday", period: "09:00-09:45", subject: "Biology", teacher: "Sana Malik" },
    ],
    attendanceHistory: [
      { date: "2026-08-18", present: true, late: false },
      { date: "2026-08-19", present: false, late: false },
    ],
    grades: [{ subject: "English", assessment: "Comprehension", marksObtained: 16, totalMarks: 20, teacherRemarks: "Great detail" }],
    termCards: [{ termName: "Term 1", percentage: 79, rank: "8th / 26", remarks: "Good writing momentum" }],
    challans: [
      {
        month: "August 2026",
        amountPkr: 14500,
        dueDate: "2026-08-10",
        paid: false,
        challanNo: "CH-IQR-0826-04",
        branchName: "Allied Bank Blue Area",
      },
    ],
  },
};

export function getTenantSlug(value?: string | null) {
  if (!value) return tenants[0].slug;
  return tenants.some((t) => t.slug === value) ? value : tenants[0].slug;
}

export function getAdminData(tenantSlug?: string | null) {
  const key = getTenantSlug(tenantSlug);
  return adminDataByTenant[key];
}

export function getTeacherData(tenantSlug?: string | null) {
  const key = getTenantSlug(tenantSlug);
  return teacherDataByTenant[key];
}

export function getParentData(tenantSlug?: string | null) {
  const key = getTenantSlug(tenantSlug);
  return parentDataByTenant[key];
}
