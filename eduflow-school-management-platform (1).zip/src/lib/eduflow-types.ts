import type { AuthRole, SubscriptionPlan } from "@/lib/authz";

export type UserRole = AuthRole;

export type AttendanceStatus = "present" | "absent" | "late";

export interface Tenant {
  id: string;
  slug: string;
  name: string;
  city: string;
  totalStudents: number;
  totalTeachers: number;
  monthlyRevenuePkr: number;
  subscriptionPlan: SubscriptionPlan;
}

export interface AttendanceRecord {
  date: string;
  present: boolean;
  late: boolean;
}

export interface GradeRecord {
  subject: string;
  assessment: string;
  marksObtained: number;
  totalMarks: number;
  teacherRemarks: string;
}

export interface FeeChallan {
  month: string;
  amountPkr: number;
  dueDate: string;
  paid: boolean;
  receiptId?: string;
  challanNo?: string;
  branchName?: string;
}

export interface TimetableItem {
  day: string;
  period: string;
  subject: string;
  teacher: string;
}

export interface TeacherClass {
  id: string;
  grade: string;
  section: string;
  subject: string;
  strength: number;
  students: string[];
}

export interface TeacherGradeInput {
  id: string;
  studentName: string;
  assessment: string;
  marks: number;
  total: number;
}

export interface TeacherDashboardData {
  teacherName: string;
  tenantSlug: string;
  classes: TeacherClass[];
  homeworkDraft: string;
  gradebook: GradeRecord[];
  examDraft: TeacherGradeInput[];
  subscriptionPlan: SubscriptionPlan;
}

export interface ReportCardTerm {
  termName: string;
  percentage: number;
  rank: string;
  remarks: string;
}

export interface ParentDashboardData {
  studentName: string;
  grade: string;
  section: string;
  rollNo: string;
  tenantSlug: string;
  timetable: TimetableItem[];
  attendanceHistory: AttendanceRecord[];
  grades: GradeRecord[];
  challans: FeeChallan[];
  termCards: ReportCardTerm[];
  subscriptionPlan: SubscriptionPlan;
}

export type UserStatus = "active" | "invited";

export interface AdminUserRow {
  name: string;
  role: UserRole;
  status: UserStatus;
}

export interface FeeCollectionRow {
  id: string;
  month: string;
  classLabel: string;
  amountPkr: number;
  paidPkr: number;
  pendingPkr: number;
  status: "healthy" | "at-risk";
}

export interface AdminRealtimeSync {
  syncedAtIso: string;
  dbUsers: number;
  dbStudents: number;
  dbChallans: number;
  dbPendingPkr: number;
  dbPaidPkr: number;
}

export interface AdminDashboardData {
  tenant: Tenant;
  activeStudents: number;
  activeTeachers: number;
  monthlyCollectionPkr: number;
  attendanceTodayPercent: number;
  pendingFeesPkr: number;
  users: AdminUserRow[];
  feeCollections: FeeCollectionRow[];
}
